#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import argparse, hashlib, json, shutil, sys
import numpy as np

ROOT_FILE=Path(__file__).resolve().parent
if str(ROOT_FILE) not in sys.path: sys.path.insert(0,str(ROOT_FILE))
from production_media_common_v10 import *

CHANNEL="EN_STORY"
SCRIPT_SCHEMA="EN_STORY_PRODUCTION_SCRIPT_v1"
MAPPING_SCHEMA="EN_STORY_VISUAL_MAPPING_v1"


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--episode",required=True); ap.add_argument("--voice-only",action="store_true"); args=ap.parse_args()
    root=Path(args.root).resolve(); ep=Path(args.episode).resolve()
    if root!=ep and root not in ep.parents: raise RuntimeError("Episode path escapes Factory root")
    mp=ep/"episode_manifest.json"; m=load(mp,{}); eid=str(m.get("episode_id") or ep.name)
    if m.get("channel_id")!=CHANNEL: raise RuntimeError(f"Runner only supports {CHANNEL}")
    spath=ep/"input"/"script"/f"{eid}_SCRIPT_FINAL.json"; maps=sorted((ep/"work"/"visual_mapping").glob(f"{eid}_VISUAL_MAPPING_v*.json"))
    if not spath.exists() or not maps: raise RuntimeError("Structured FINAL script or visual mapping missing")
    script=load(spath,{}); mapping=load(maps[-1],{})
    if script.get("schema")!=SCRIPT_SCHEMA: raise RuntimeError("Unexpected EN_STORY script schema")
    if mapping.get("schema")!=MAPPING_SCHEMA: raise RuntimeError("Unexpected EN_STORY visual mapping schema")
    lines=script.get("lines") or []; casting=script.get("casting") or {}
    if not lines: raise RuntimeError("FINAL script has no lines")
    ffmpeg=shutil.which("ffmpeg"); ffprobe=shutil.which("ffprobe")
    if not ffmpeg or not ffprobe: raise RuntimeError("ffmpeg/ffprobe missing")
    try:
        from kokoro import KPipeline
    except Exception as e: raise RuntimeError("Kokoro import failed: "+repr(e))
    pipe=KPipeline(lang_code="a")
    work_voice=ep/"work"/"voice"; cues=work_voice/"cues"; cues.mkdir(parents=True,exist_ok=True)
    parts=[]; pauses=[]; cue_durations=[]; active=[]; speakers=[]; cache_hits=0
    total=len(lines)
    for i,row in enumerate(lines,1):
        lid=str(row.get("id") or f"L{i:03d}"); speaker=str(row.get("speaker") or ""); text=str(row.get("text") or "").strip(); cfg=casting.get(speaker) or {}
        voice=str(cfg.get("voice") or "").strip(); speed=float(cfg.get("speed",1.0)); pause=max(0.0,float(row.get("pause_after",0.35)))
        if not voice or not text: raise RuntimeError(f"Missing voice/text for {lid}")
        progress(ep,eid,"VOICE",f"Synthesizing dialogue · {i}/{total}",i-1,total,cache_hits)
        key=hashlib.sha256((text+"\0"+voice+"\0"+str(speed)).encode()).hexdigest()[:16]; p=cues/f"{lid}_{key}.wav"
        if p.exists(): cache_hits+=1
        else:
            chunks=[]
            for item in pipe(text,voice=voice,speed=speed): chunks.append(np.asarray(item[-1],dtype=np.float32).reshape(-1))
            if not chunks: raise RuntimeError(f"Kokoro produced no audio for {lid}")
            write_pcm16(p,np.concatenate(chunks),24000)
        info=wav_info(p)
        if info["sample_rate"]!=24000 or info["channels"]!=1: raise RuntimeError(f"Unexpected Kokoro WAV format for {lid}")
        parts.append(p); pauses.append(pause); cue_durations.append(info["duration"]); active.append(active_bounds(p)); speakers.append(speaker)
    pcm=work_voice/f"{eid}_NARRATION_PCM24.wav"; master=work_voice/f"{eid}_NARRATION_FINAL.wav"; minfo,offsets=concat_voice(parts,pauses,pcm,master,ffmpeg)
    progress(ep,eid,"TIMING","Aligning dialogue cues to actual generated WAV",total,total,cache_hits)
    timing=[]; line_durations=[]
    for i,(row,off,dur,bounds,pause) in enumerate(zip(lines,offsets,cue_durations,active,pauses),1):
        alo,ahi=bounds; st=off+alo; en=off+ahi
        if i==total: en=minfo["duration"]
        if en<=st: en=min(minfo["duration"],off+dur)
        line_durations.append(dur+pause)
        timing.append({"cue":i,"line_id":row.get("id") or f"L{i:03d}","speaker":row.get("speaker"),"subtitle_text":str(row.get("subtitle_text") or row.get("text") or ""),"spoken_text":str(row.get("text") or ""),"clip_start":off,"speech_start":st,"speech_end":en,"clip_duration":dur,"pause_after":pause})
    tdir=ep/"work"/"timing"; tpath=tdir/f"{eid}_TIMING_v01.json"; save(tpath,{"schema":"EN_STORY_ACTUAL_WAV_TIMING_v1","episode_id":eid,"audio":str(master.relative_to(ep)),"audio_duration":minfo["duration"],"cues":timing})
    sdir=ep/"work"/"srt"; sdir.mkdir(parents=True,exist_ok=True); out_srt=sdir/f"{eid}_UPLOAD_v01.srt"
    blocks=[f"{q['cue']}\n{srt_time(q['speech_start'])} --> {srt_time(q['speech_end'])}\n{q['subtitle_text']}\n" for q in timing]; out_srt.write_text("\n".join(blocks),encoding="utf-8")
    if args.voice_only:
        progress(ep,eid,"VOICE","Voice-only build complete",total,total,cache_hits,state="COMPLETE"); return 0
    progress(ep,eid,"EDIT_PLAN","Building story-beat visual runs",0,total,cache_hits)
    rcache=ep/"work"/"render_cache"; rcache.mkdir(parents=True,exist_ok=True); silent=rcache/f"{eid}_story_silent.mp4"
    render_visual_timeline(ffmpeg,ep/"input"/"visuals",mapping,line_durations,speakers,rcache,silent)
    outdir=ep/"output"/"preview"; outdir.mkdir(parents=True,exist_ok=True); ver=next_version(outdir,f"{eid}_PREVIEW_",".mp4"); preview=outdir/f"{eid}_PREVIEW_v{ver:02d}.mp4"
    progress(ep,eid,"RENDER","Muxing 1920x1080 story preview",0,total,cache_hits); probe=finalize_preview(ffmpeg,ffprobe,silent,master,preview)
    progress(ep,eid,"AUTO_QC","Running story media QC",total,total,cache_hits)
    streams=probe.get("streams",[]); video=next((x for x in streams if x.get("codec_type")=="video"),{}); audio=next((x for x in streams if x.get("codec_type")=="audio"),{})
    vdur=float(probe.get("format",{}).get("duration",0) or 0); adur=float(minfo["duration"]); delta=abs(vdur-adur)
    focus_runs=[r for r in mapping.get("runs",[]) if r.get("speaker_focus")]
    checks=[
      {"name":"Preview exists","pass":preview.exists() and preview.stat().st_size>10000,"detail":preview.stat().st_size if preview.exists() else 0},
      {"name":"1920x1080 H264","pass":video.get("width")==1920 and video.get("height")==1080 and str(video.get("codec_name","")).lower()=="h264","detail":f"{video.get('width')}x{video.get('height')} {video.get('codec_name')}"},
      {"name":"AAC audio","pass":str(audio.get("codec_name","")).lower()=="aac","detail":audio.get("codec_name")},
      {"name":"A/V sync","pass":delta<=0.15,"detail":f"video={vdur:.3f}s wav={adur:.3f}s delta={delta:.3f}s"},
      {"name":"Actual-WAV cue timing","pass":bool(timing) and abs(timing[-1]["speech_end"]-adur)<=0.01,"detail":f"last={timing[-1]['speech_end']:.3f}s audio={adur:.3f}s"},
      {"name":"Speaker Focus fixed-frame rule","pass":all(str(r.get("motion") or "STATIC").upper()=="STATIC" for r in focus_runs),"detail":f"focus runs={len(focus_runs)}"},
      {"name":"No per-line motion reset","pass":all(int(r.get("line_end",0))>=int(r.get("line_start",0)) for r in mapping.get("runs",[])),"detail":f"visual runs={len(mapping.get('runs',[]))} lines={len(lines)}"},
    ]
    qc={"schema":"EN_STORY_MEDIA_QC_v1","episode_id":eid,"created_at":now(),"status":"PASS" if all(x["pass"] for x in checks) else "FAIL","checks":checks,"metrics":{"audio_duration":adur,"video_duration":vdur,"delta":delta,"lines":len(lines),"visual_runs":len(mapping.get("runs",[])),"speaker_focus_runs":len(focus_runs),"cache_hits":cache_hits},"outputs":{"preview":str(preview.relative_to(ep)),"narration":str(master.relative_to(ep)),"timing":str(tpath.relative_to(ep)),"srt":str(out_srt.relative_to(ep))}}
    qpath=outdir/f"{eid}_QC_v{ver:02d}.json"; save(qpath,qc)
    if qc["status"]!="PASS": raise RuntimeError("Auto QC failed")
    for st in ["VOICE","TIMING","SUBTITLES","EDIT_PLAN","RENDER","AUTO_QC"]: set_stage(m,st,"COMPLETE")
    set_stage(m,"PREVIEW_REVIEW","NEEDS_REVIEW",current=True); save(mp,m); progress(ep,eid,"PREVIEW_REVIEW","Preview ready for human review",total,total,cache_hits,state="COMPLETE")
    print(json.dumps({"status":"PASS","preview":str(preview),"qc":str(qpath),"audio_duration":adur,"video_duration":vdur,"cache_hits":cache_hits},ensure_ascii=False,indent=2)); return 0

if __name__=="__main__": raise SystemExit(main())
