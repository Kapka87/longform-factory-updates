#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import argparse, hashlib, json, shutil, sys, urllib.parse, urllib.request

ROOT_FILE=Path(__file__).resolve().parent
if str(ROOT_FILE) not in sys.path: sys.path.insert(0,str(ROOT_FILE))
from production_media_common_v10 import *

CHANNEL="JP_BTS"
SCRIPT_SCHEMA="JP_BTS_PRODUCTION_SCRIPT_v1"
MAPPING_SCHEMA="JP_BTS_VISUAL_MAPPING_v1"
VOICEVOX="http://127.0.0.1:50021"


def http_json(url,method="GET",data=None,timeout=30):
    body=None; headers={}
    if data is not None: body=json.dumps(data,ensure_ascii=False).encode("utf-8"); headers["Content-Type"]="application/json"
    req=urllib.request.Request(url,data=body,headers=headers,method=method)
    with urllib.request.urlopen(req,timeout=timeout) as r: return json.loads(r.read().decode("utf-8"))

def resolve_roles(casting):
    speakers=http_json(VOICEVOX+"/speakers"); resolved={}
    for role,cfg in casting.items():
        if "style_id" in cfg: raise RuntimeError("Hard-coded VOICEVOX style_id is forbidden")
        sn=str(cfg.get("speaker_name") or "").strip(); st=str(cfg.get("style_name") or "").strip()
        sp=next((x for x in speakers if str(x.get("name"))==sn),None)
        if not sp: raise RuntimeError(f"VOICEVOX speaker not found: {sn}")
        style=next((x for x in sp.get("styles",[]) if str(x.get("name"))==st),None)
        if not style: raise RuntimeError(f"VOICEVOX style not found: {sn} / {st}")
        resolved[role]={"speaker_name":sn,"style_name":st,"style_id":int(style["id"]),"speaker_uuid":sp.get("speaker_uuid"),"gender":cfg.get("gender")}
    return resolved

def synth(text,style_id,out):
    qurl=VOICEVOX+"/audio_query?"+urllib.parse.urlencode({"text":text,"speaker":style_id})
    query=http_json(qurl,method="POST",timeout=30)
    surl=VOICEVOX+"/synthesis?"+urllib.parse.urlencode({"speaker":style_id})
    req=urllib.request.Request(surl,data=json.dumps(query,ensure_ascii=False).encode("utf-8"),headers={"Content-Type":"application/json"},method="POST")
    with urllib.request.urlopen(req,timeout=60) as r: raw=r.read()
    Path(out).parent.mkdir(parents=True,exist_ok=True); Path(out).write_bytes(raw)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--episode",required=True); ap.add_argument("--voice-only",action="store_true"); args=ap.parse_args()
    root=Path(args.root).resolve(); ep=Path(args.episode).resolve()
    if root!=ep and root not in ep.parents: raise RuntimeError("Episode path escapes Factory root")
    mp=ep/"episode_manifest.json"; m=load(mp,{}); eid=str(m.get("episode_id") or ep.name)
    if m.get("channel_id")!=CHANNEL: raise RuntimeError(f"Runner only supports {CHANNEL}")
    spath=ep/"input"/"script"/f"{eid}_SCRIPT_FINAL.json"; maps=sorted((ep/"work"/"visual_mapping").glob(f"{eid}_VISUAL_MAPPING_v*.json"))
    if not spath.exists() or not maps: raise RuntimeError("Structured FINAL script or visual mapping missing")
    script=load(spath,{}); mapping=load(maps[-1],{})
    if script.get("schema")!=SCRIPT_SCHEMA: raise RuntimeError("Unexpected JP_BTS script schema")
    if mapping.get("schema")!=MAPPING_SCHEMA: raise RuntimeError("Unexpected JP_BTS visual mapping schema")
    lines=script.get("lines") or []; casting=script.get("casting") or {}
    if not lines: raise RuntimeError("FINAL script has no lines")
    ffmpeg=shutil.which("ffmpeg"); ffprobe=shutil.which("ffprobe")
    if not ffmpeg or not ffprobe: raise RuntimeError("ffmpeg/ffprobe missing")
    try: http_json(VOICEVOX+"/version",timeout=2)
    except Exception as e: raise RuntimeError("VOICEVOX unavailable: "+repr(e))
    resolved=resolve_roles(casting)
    work_voice=ep/"work"/"voice"; cues=work_voice/"cues"; cues.mkdir(parents=True,exist_ok=True); save(work_voice/f"{eid}_VOICE_ROLE_MAP.json",{"schema":"JP_BTS_VOICE_ROLE_MAP_v1","episode_id":eid,"resolved_at":now(),"roles":resolved})
    parts=[]; pauses=[]; cue_durations=[]; active=[]; speakers=[]; cache_hits=0; total=len(lines)
    for i,row in enumerate(lines,1):
        lid=str(row.get("id") or f"L{i:03d}"); role=str(row.get("speaker") or ""); spoken=str(row.get("spoken_text") or row.get("text") or "").strip(); pause=max(0.0,float(row.get("pause_after",0.35))); rr=resolved.get(role)
        if not rr or not spoken: raise RuntimeError(f"Missing resolved role/spoken text for {lid}")
        progress(ep,eid,"VOICE",f"Synthesizing VOICEVOX · {i}/{total}",i-1,total,cache_hits)
        key=hashlib.sha256((spoken+"\0"+rr["speaker_name"]+"\0"+rr["style_name"]).encode()).hexdigest()[:16]; p=cues/f"{lid}_{key}.wav"
        if p.exists(): cache_hits+=1
        else: synth(spoken,rr["style_id"],p)
        info=wav_info(p); parts.append(p); pauses.append(pause); cue_durations.append(info["duration"]); active.append(active_bounds(p,threshold=0.008,pad=0.03)); speakers.append(role)
    pcm=work_voice/f"{eid}_NARRATION_PCM.wav"; master=work_voice/f"{eid}_NARRATION_FINAL.wav"; minfo,offsets=concat_voice(parts,pauses,pcm,master,ffmpeg)
    progress(ep,eid,"TIMING","Aligning Japanese cues to actual generated WAV",total,total,cache_hits)
    timing=[]; line_durations=[]
    for i,(row,off,dur,bounds,pause) in enumerate(zip(lines,offsets,cue_durations,active,pauses),1):
        alo,ahi=bounds; st=off+alo; en=off+ahi
        if i==total: en=minfo["duration"]
        if en<=st: en=min(minfo["duration"],off+dur)
        line_durations.append(dur+pause)
        timing.append({"cue":i,"line_id":row.get("id") or f"L{i:03d}","speaker":row.get("speaker"),"subtitle_text":str(row.get("subtitle_text") or row.get("text") or ""),"spoken_text":str(row.get("spoken_text") or row.get("text") or ""),"clip_start":off,"speech_start":st,"speech_end":en,"clip_duration":dur,"pause_after":pause})
    tdir=ep/"work"/"timing"; tpath=tdir/f"{eid}_TIMING_v01.json"; save(tpath,{"schema":"JP_BTS_ACTUAL_WAV_TIMING_v1","episode_id":eid,"audio":str(master.relative_to(ep)),"audio_duration":minfo["duration"],"cues":timing,"voice_role_map":str((work_voice/f'{eid}_VOICE_ROLE_MAP.json').relative_to(ep))})
    sdir=ep/"work"/"srt"; sdir.mkdir(parents=True,exist_ok=True); out_srt=sdir/f"{eid}_UPLOAD_v01.srt"; out_srt.write_text("\n".join(f"{q['cue']}\n{srt_time(q['speech_start'])} --> {srt_time(q['speech_end'])}\n{q['subtitle_text']}\n" for q in timing),encoding="utf-8")
    if args.voice_only:
        progress(ep,eid,"VOICE","Voice-only build complete",total,total,cache_hits,state="COMPLETE"); return 0
    progress(ep,eid,"EDIT_PLAN","Building information-beat visual runs",0,total,cache_hits)
    rcache=ep/"work"/"render_cache"; rcache.mkdir(parents=True,exist_ok=True); silent=rcache/f"{eid}_jp_bts_silent.mp4"; render_visual_timeline(ffmpeg,ep/"input"/"visuals",mapping,line_durations,speakers,rcache,silent)
    outdir=ep/"output"/"preview"; outdir.mkdir(parents=True,exist_ok=True); ver=next_version(outdir,f"{eid}_PREVIEW_",".mp4"); preview=outdir/f"{eid}_PREVIEW_v{ver:02d}.mp4"
    progress(ep,eid,"RENDER","Muxing 1920x1080 JP_BTS preview",0,total,cache_hits); probe=finalize_preview(ffmpeg,ffprobe,silent,master,preview)
    progress(ep,eid,"AUTO_QC","Running JP_BTS media QC",total,total,cache_hits)
    streams=probe.get("streams",[]); video=next((x for x in streams if x.get("codec_type")=="video"),{}); audio=next((x for x in streams if x.get("codec_type")=="audio"),{})
    vdur=float(probe.get("format",{}).get("duration",0) or 0); adur=float(minfo["duration"]); delta=abs(vdur-adur)
    checks=[
      {"name":"Preview exists","pass":preview.exists() and preview.stat().st_size>10000,"detail":preview.stat().st_size if preview.exists() else 0},
      {"name":"1920x1080 H264","pass":video.get("width")==1920 and video.get("height")==1080 and str(video.get("codec_name","")).lower()=="h264","detail":f"{video.get('width')}x{video.get('height')} {video.get('codec_name')}"},
      {"name":"AAC audio","pass":str(audio.get("codec_name","")).lower()=="aac","detail":audio.get("codec_name")},
      {"name":"A/V sync","pass":delta<=0.15,"detail":f"video={vdur:.3f}s wav={adur:.3f}s delta={delta:.3f}s"},
      {"name":"Actual-WAV cue timing","pass":bool(timing) and abs(timing[-1]["speech_end"]-adur)<=0.01,"detail":f"last={timing[-1]['speech_end']:.3f}s audio={adur:.3f}s"},
      {"name":"Dynamic VOICEVOX role mapping","pass":all("style_id" in x and x.get("speaker_name") and x.get("style_name") for x in resolved.values()),"detail":", ".join(f"{r}:{x['speaker_name']}/{x['style_name']}→{x['style_id']}" for r,x in resolved.items())},
      {"name":"No hard-coded style ID in script","pass":all("style_id" not in (casting.get(r) or {}) for r in casting),"detail":"speaker_name + style_name only"},
    ]
    qc={"schema":"JP_BTS_MEDIA_QC_v1","episode_id":eid,"created_at":now(),"status":"PASS" if all(x["pass"] for x in checks) else "FAIL","checks":checks,"metrics":{"audio_duration":adur,"video_duration":vdur,"delta":delta,"lines":len(lines),"visual_runs":len(mapping.get("runs",[])),"cache_hits":cache_hits},"outputs":{"preview":str(preview.relative_to(ep)),"narration":str(master.relative_to(ep)),"timing":str(tpath.relative_to(ep)),"srt":str(out_srt.relative_to(ep))}}
    qpath=outdir/f"{eid}_QC_v{ver:02d}.json"; save(qpath,qc)
    if qc["status"]!="PASS": raise RuntimeError("Auto QC failed")
    for st in ["VOICE","TIMING","SUBTITLES","EDIT_PLAN","RENDER","AUTO_QC"]: set_stage(m,st,"COMPLETE")
    set_stage(m,"PREVIEW_REVIEW","NEEDS_REVIEW",current=True); save(mp,m); progress(ep,eid,"PREVIEW_REVIEW","Preview ready for human review",total,total,cache_hits,state="COMPLETE")
    print(json.dumps({"status":"PASS","preview":str(preview),"qc":str(qpath),"audio_duration":adur,"video_duration":vdur,"cache_hits":cache_hits,"voice_roles":resolved},ensure_ascii=False,indent=2)); return 0

if __name__=="__main__": raise SystemExit(main())
