#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, math, re, shutil, subprocess, sys, wave

import numpy as np

VOICE="af_heart"
SPEED=0.96
SAMPLE_RATE=24000
GAP_SEC=0.20

def now(): return datetime.now(timezone.utc).isoformat()
def load(path,default=None):
    try:return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:return {} if default is None else default
def save(path,obj):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+".tmp"); tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); tmp.replace(path)
def run(cmd,timeout=300):
    p=subprocess.run([str(x) for x in cmd],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
    if p.returncode!=0: raise RuntimeError("command failed: "+" ".join(map(str,cmd))+"\n"+p.stderr[-2000:])
    return p.stdout

def srt_time(sec):
    ms=max(0,int(round(sec*1000))); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def wav_info(path):
    with wave.open(str(path),"rb") as w:
        return {"frames":w.getnframes(),"sample_rate":w.getframerate(),"channels":w.getnchannels(),"sample_width":w.getsampwidth(),"duration":w.getnframes()/w.getframerate()}

def write_pcm16(path,audio,sr=SAMPLE_RATE):
    a=np.asarray(audio,dtype=np.float32).reshape(-1); a=np.clip(a,-1,1); pcm=(a*32767.0).astype("<i2")
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    with wave.open(str(path),"wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(int(sr)); w.writeframes(pcm.tobytes())

def active_bounds(path):
    with wave.open(str(path),"rb") as w:
        if w.getnchannels()!=1 or w.getsampwidth()!=2: return 0.0,w.getnframes()/max(1,w.getframerate())
        sr=w.getframerate(); raw=w.readframes(w.getnframes())
    a=np.abs(np.frombuffer(raw,dtype="<i2").astype(np.int32))
    if not len(a) or int(a.max(initial=0))<60: return 0.0,len(a)/sr
    threshold=max(120,int(a.max()*0.018)); idx=np.flatnonzero(a>=threshold)
    if not len(idx): return 0.0,len(a)/sr
    pad=int(sr*0.04); lo=max(0,int(idx[0])-pad); hi=min(len(a),int(idx[-1])+pad+1)
    return lo/sr,hi/sr

def concat_wavs(parts,out,gap_sec=GAP_SEC):
    infos=[wav_info(p) for p in parts]
    if not infos: raise RuntimeError("No voice parts")
    sr=infos[0]["sample_rate"]; ch=infos[0]["channels"]; sw=infos[0]["sample_width"]
    if any((x["sample_rate"],x["channels"],x["sample_width"])!=(sr,ch,sw) for x in infos): raise RuntimeError("WAV format mismatch")
    gap_frames=int(round(sr*gap_sec)); gap=b"\x00"*(gap_frames*ch*sw); offsets=[]; t=0.0
    with wave.open(str(out),"wb") as dst:
        dst.setnchannels(ch); dst.setsampwidth(sw); dst.setframerate(sr)
        for i,p in enumerate(parts):
            offsets.append(t)
            with wave.open(str(p),"rb") as src:
                raw=src.readframes(src.getnframes()); dst.writeframes(raw)
            t+=infos[i]["duration"]
            if i<len(parts)-1: dst.writeframes(gap); t+=gap_sec
    return wav_info(out),offsets

def parse_script(text):
    blocks=re.split(r"\n\s*\n+",text.strip()) if text.strip() else []
    beats=[]; pending_visual=None
    for block in blocks:
        lines=[x.strip() for x in block.splitlines() if x.strip()]
        spoken=[]
        for line in lines:
            if re.fullmatch(r"V\d{2,3}",line,re.I): pending_visual=line.upper(); continue
            spoken.append(line)
        if not spoken: continue
        beats.append({"beat":len(beats)+1,"marker":pending_visual,"subtitle_text":"\n".join(spoken),"spoken_text":" ".join(spoken)})
        pending_visual=None
    if not beats: raise RuntimeError("FINAL script contains no spoken beats")
    return beats

def resolve_visuals(mapping,beats,visual_dir):
    visuals={str(v.get("id")):v for v in mapping.get("visuals",[]) if isinstance(v,dict) and v.get("id")}
    assignment={}
    for r in mapping.get("runs",[]):
        vid=str(r.get("visual_id") or ""); a=int(r.get("beat_start",0)); b=int(r.get("beat_end",0))
        if vid not in visuals or a<1 or b<a: raise RuntimeError("Invalid visual run")
        for n in range(a,b+1):
            if n in assignment: raise RuntimeError(f"Beat {n} mapped more than once")
            assignment[n]=vid
    if sorted(assignment)!=list(range(1,len(beats)+1)): raise RuntimeError("Visual runs do not cover every spoken beat exactly once")
    from PIL import Image
    paths={}
    for vid,v in visuals.items():
        fn=str(v.get("filename") or ""); p=Path(visual_dir)/fn
        if not p.exists(): raise RuntimeError(f"Visual missing: {fn}")
        with Image.open(p) as im:
            if tuple(im.size)!=(1920,1080): raise RuntimeError(f"Visual must be 1920x1080: {fn} = {im.size}")
        paths[vid]=p
    return [paths[assignment[b["beat"]]] for b in beats],[assignment[b["beat"]] for b in beats]

def next_version(folder,prefix,suffix):
    folder=Path(folder); folder.mkdir(parents=True,exist_ok=True); best=0
    rx=re.compile(re.escape(prefix)+r"v(\d+?)"+re.escape(suffix)+r"$")
    for p in folder.iterdir():
        m=rx.match(p.name)
        if m: best=max(best,int(m.group(1)))
    return best+1

def progress(ep,eid,stage,message,current=None,total=None,cache_hits=None,state="RUNNING"):
    p=Path(ep)/"work"/"job_status.json"; cur=load(p,{})
    cur.update({"episode_id":eid,"job":cur.get("job") or "BUILD_PREVIEW","state":state,"stage":stage,"message":message,"updated_at":now()})
    if current is not None: cur["item_current"]=current
    if total is not None: cur["item_total"]=total
    if cache_hits is not None: cur["cache_hits"]=cache_hits
    save(p,cur)

def set_stage(m,stage,state,current=False):
    lc=m.setdefault("lifecycle",{}); it=lc.setdefault("stages",{}).setdefault(stage,{}); it["runtime_state"]=state; it["updated_at"]=now()
    if current: lc["current_stage"]=stage

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--episode",required=True); ap.add_argument("--voice-only",action="store_true"); args=ap.parse_args()
    root=Path(args.root).resolve(); ep=Path(args.episode).resolve()
    if root!=ep and root not in ep.parents: raise RuntimeError("Episode path escapes Factory root")
    mp=ep/"episode_manifest.json"; m=load(mp,{}); eid=str(m.get("episode_id") or ep.name)
    if m.get("channel_id")!="EN_BTS": raise RuntimeError("Runner only supports EN_BTS")
    scripts=sorted((ep/"input"/"script").glob(f"{eid}_SCRIPT_FINAL.txt")); maps=sorted((ep/"work"/"visual_mapping").glob(f"{eid}_VISUAL_MAPPING_v*.json"))
    if not scripts or not maps: raise RuntimeError("FINAL script or visual mapping missing")
    beats=parse_script(scripts[-1].read_text(encoding="utf-8")); mapping=load(maps[-1],{})
    visual_paths,visual_ids=resolve_visuals(mapping,beats,ep/"input"/"visuals")
    try:
        from kokoro import KPipeline
    except Exception as e: raise RuntimeError("Kokoro import failed: "+repr(e))
    work_voice=ep/"work"/"voice"; cues=work_voice/"cues"; cues.mkdir(parents=True,exist_ok=True)
    pipe=KPipeline(lang_code="a"); parts=[]; durs=[]; actives=[]; cache_hits=0
    total=len(beats)
    for i,b in enumerate(beats,1):
        progress(ep,eid,"VOICE",f"Synthesizing narration · {i}/{total}",i-1,total,cache_hits)
        key=hashlib.sha256((b["spoken_text"]+"\0"+VOICE+"\0"+str(SPEED)).encode()).hexdigest()[:16]
        p=cues/f"B{i:03d}_{key}.wav"
        if p.exists(): cache_hits+=1
        else:
            chunks=[]
            for item in pipe(b["spoken_text"],voice=VOICE,speed=SPEED): chunks.append(np.asarray(item[-1],dtype=np.float32).reshape(-1))
            if not chunks: raise RuntimeError(f"Kokoro produced no audio for beat {i}")
            write_pcm16(p,np.concatenate(chunks),SAMPLE_RATE)
        info=wav_info(p)
        if info["sample_rate"]!=SAMPLE_RATE or info["channels"]!=1: raise RuntimeError("Unexpected Kokoro WAV format")
        parts.append(p); durs.append(info["duration"]); actives.append(active_bounds(p))
    master=work_voice/f"{eid}_NARRATION_FINAL.wav"; master.parent.mkdir(parents=True,exist_ok=True)
    minfo,offsets=concat_wavs(parts,master)
    progress(ep,eid,"TIMING","Aligning cues to actual generated WAV",total,total,cache_hits)
    timing=[]
    for i,(b,off,dur,(alo,ahi),vid) in enumerate(zip(beats,offsets,durs,actives,visual_ids),1):
        st=off+alo; en=off+ahi
        if i==len(beats): en=minfo["duration"]
        if en<=st: en=min(minfo["duration"],off+dur)
        timing.append({"cue":i,"beat":b["beat"],"visual_id":vid,"subtitle_text":b["subtitle_text"],"spoken_text":b["spoken_text"],"clip_start":off,"speech_start":st,"speech_end":en,"clip_duration":dur})
    tdir=ep/"work"/"timing"; tdir.mkdir(parents=True,exist_ok=True); tpath=tdir/f"{eid}_TIMING_v01.json"; save(tpath,{"schema":"EN_BTS_ACTUAL_WAV_TIMING_v1","episode_id":eid,"audio":str(master.relative_to(ep)),"audio_duration":minfo["duration"],"gap_sec":GAP_SEC,"cues":timing})
    sdir=ep/"work"/"srt"; sdir.mkdir(parents=True,exist_ok=True); spath=sdir/f"{eid}_UPLOAD_v01.srt"
    blocks=[]
    for q in timing: blocks.append(f"{q['cue']}\n{srt_time(q['speech_start'])} --> {srt_time(q['speech_end'])}\n{q['subtitle_text']}\n")
    spath.write_text("\n".join(blocks),encoding="utf-8")
    if args.voice_only:
        progress(ep,eid,"VOICE","Voice-only build complete",total,total,cache_hits,state="COMPLETE"); return 0
    ffmpeg=shutil.which("ffmpeg"); ffprobe=shutil.which("ffprobe")
    if not ffmpeg or not ffprobe: raise RuntimeError("ffmpeg/ffprobe missing")
    progress(ep,eid,"EDIT_PLAN","Building static information-beat edit plan",0,total,cache_hits)
    rcache=ep/"work"/"render_cache"; rcache.mkdir(parents=True,exist_ok=True); concat=rcache/"en_bts_visuals.ffconcat"
    rows=["ffconcat version 1.0"]
    def esc(p): return str(p).replace("'","'\\''")
    for i,p in enumerate(visual_paths):
        seg=durs[i]+(GAP_SEC if i<len(durs)-1 else 0.0)
        rows += [f"file '{esc(p)}'",f"duration {max(0.05,seg):.6f}"]
    rows.append(f"file '{esc(visual_paths[-1])}'")
    concat.write_text("\n".join(rows)+"\n",encoding="utf-8")
    outdir=ep/"output"/"preview"; outdir.mkdir(parents=True,exist_ok=True)
    ver=next_version(outdir,f"{eid}_PREVIEW_",".mp4")
    silent=rcache/f"{eid}_silent_v{ver:02d}.mp4"; preview=outdir/f"{eid}_PREVIEW_v{ver:02d}.mp4"
    progress(ep,eid,"RENDER","Rendering 1920x1080 preview",0,total,cache_hits)
    run([ffmpeg,"-y","-hide_banner","-loglevel","error","-f","concat","-safe","0","-i",concat,"-vf","fps=30,format=yuv420p","-c:v","libx264","-preset","veryfast","-movflags","+faststart",silent],300)
    run([ffmpeg,"-y","-hide_banner","-loglevel","error","-i",silent,"-i",master,"-c:v","copy","-c:a","aac","-b:a","160k","-shortest","-movflags","+faststart",preview],300)
    progress(ep,eid,"AUTO_QC","Running ffprobe and timing QC",total,total,cache_hits)
    probe=json.loads(run([ffprobe,"-v","error","-show_entries","format=duration:stream=width,height,codec_type,codec_name","-of","json",preview],60))
    streams=probe.get("streams",[]); video=next((x for x in streams if x.get("codec_type")=="video"),{}); audio=next((x for x in streams if x.get("codec_type")=="audio"),{})
    vdur=float(probe.get("format",{}).get("duration",0) or 0); adur=float(minfo["duration"]); delta=abs(vdur-adur)
    checks=[
        {"name":"Preview exists","pass":preview.exists() and preview.stat().st_size>10000,"detail":preview.stat().st_size if preview.exists() else 0},
        {"name":"1920x1080 H264","pass":video.get("width")==1920 and video.get("height")==1080 and str(video.get("codec_name","")).lower()=="h264","detail":f"{video.get('width')}x{video.get('height')} {video.get('codec_name')}"},
        {"name":"AAC audio","pass":str(audio.get("codec_name","")).lower()=="aac","detail":audio.get("codec_name")},
        {"name":"A/V sync","pass":delta<=0.15,"detail":f"video={vdur:.3f}s wav={adur:.3f}s delta={delta:.3f}s"},
        {"name":"Actual-WAV cue timing","pass":bool(timing) and timing[-1]["speech_end"]<=adur+0.002,"detail":f"last={timing[-1]['speech_end']:.3f}s audio={adur:.3f}s"},
        {"name":"All visual runs mapped","pass":len(visual_paths)==len(beats),"detail":f"{len(visual_paths)}/{len(beats)}"},
    ]
    qc={"schema":"EN_BTS_MEDIA_QC_v1","episode_id":eid,"created_at":now(),"status":"PASS" if all(x["pass"] for x in checks) else "FAIL","checks":checks,"metrics":{"audio_duration":adur,"video_duration":vdur,"delta":delta,"beats":len(beats),"cache_hits":cache_hits},"outputs":{"preview":str(preview.relative_to(ep)),"narration":str(master.relative_to(ep)),"timing":str(tpath.relative_to(ep)),"srt":str(spath.relative_to(ep))}}
    qpath=outdir/f"{eid}_QC_v{ver:02d}.json"; save(qpath,qc)
    if qc["status"]!="PASS": raise RuntimeError("Auto QC failed")
    for st in ["VOICE","TIMING","SUBTITLES","EDIT_PLAN","RENDER","AUTO_QC"]: set_stage(m,st,"COMPLETE")
    set_stage(m,"PREVIEW_REVIEW","NEEDS_REVIEW",current=True); save(mp,m)
    progress(ep,eid,"PREVIEW_REVIEW","Preview ready for human review",total,total,cache_hits,state="COMPLETE")
    print(json.dumps({"status":"PASS","preview":str(preview),"qc":str(qpath),"audio_duration":adur,"video_duration":vdur,"cache_hits":cache_hits},ensure_ascii=False,indent=2))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
