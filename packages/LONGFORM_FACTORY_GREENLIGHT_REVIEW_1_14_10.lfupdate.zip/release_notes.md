# Longform Factory v1.14.0 — Four-Channel Production Integration

- EN_STORY production adapter + Kokoro two-voice story runner + fixed-frame Speaker Focus
- EN_BTS production v1.2 with publishing approval through UPLOAD_READY
- JP_BTS production adapter + dynamic VOICEVOX speaker/style mapping
- JP_STORY remains the active media reference
- Adapter Registry v2.0
- Four-channel isolated production QA
- Existing Episode adapter pins are never auto-migrated
- Image generation remains provider-neutral


R3: Fixes bootstrap startup by resolving the QA module path explicitly and injecting Production QA routes at do_GET/do_POST boundaries without depending on the removed local-upload route.


1.14.3 hotfix: production_media_common_v10 now defines resolve_executable(), shared by production runners, including standard macOS Homebrew locations.


1.14.4 hotfix: shared executable resolution is applied to both adapter preflight and production runner modules so Desktop-app execution finds macOS Homebrew ffmpeg/ffprobe consistently.


1.14.5 hotfix: EN_BTS production_adapter_v11 and media runner now use the shared Desktop-safe ffmpeg/ffprobe resolver.


1.14.6: JP_BTS Discovery Gate v2 adds D0 Wide -> D1 Market Screen -> D2 Deep Validation. Existing pinned episodes are not auto-migrated.


1.14.7: Preserve AI result JSON textarea drafts across dashboard detail refreshes; align JP_BTS integration QA with adapter v1.1.


1.14.8: Remove v1.14.7 MutationObserver workaround; preserve AI result input without stealing focus or disabling editing.


1.14.9: Guard dashboard refresh while #resultbox owns focus.


1.14.10: Add explicit JP_BTS Greenlight review actions; approval advances to Editorial Ready.
