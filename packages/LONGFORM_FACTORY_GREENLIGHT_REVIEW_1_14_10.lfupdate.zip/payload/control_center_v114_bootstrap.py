#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import os, runpy, sys

ROOT=Path(os.environ.get("LONGFORM_FACTORY_ROOT",str(Path.home()/"Desktop"/"KohoroAudition"/"LongformFactory_v1_Production"))).expanduser().resolve()
qa_dir=ROOT/"factory"/"qa"
if str(qa_dir) not in sys.path:
    sys.path.insert(0,str(qa_dir))

src=ROOT/"factory"/"control_center_current.py"
text=src.read_text(encoding="utf-8")
if 'FACTORY_VERSION="1.13.0"' in text:
    text=text.replace('FACTORY_VERSION="1.13.0"','FACTORY_VERSION="1.14.10"',1)
elif 'FACTORY_VERSION="1.14.4"' not in text:
    raise RuntimeError("v1.14 bootstrap runtime-version anchor missing")

text=text.replace('if channel=="JP_STORY" and str(m.get("schema_version"))=="1.2":','if str(m.get("schema_version"))=="1.2":',1)

imp='from four_channel_production_integration import four_channel_production_status, run_four_channel_production_qa\n'
anchor='from cross_channel_media_smoke import media_smoke_status, run_media_smoke\n'
if imp.strip() not in text:
    if anchor not in text:
        raise RuntimeError("v1.14 bootstrap import anchor missing")
    text=text.replace(anchor,anchor+imp,1)

get_method='    def do_GET(self):\n'
get_route="""    def do_GET(self):
        if self.path.split("?",1)[0]=="/api/four-channel-production/status":
            self.send_json(four_channel_production_status(ROOT)); return
"""
if '/api/four-channel-production/status' not in text:
    if get_method not in text:
        raise RuntimeError("v1.14 do_GET anchor missing")
    text=text.replace(get_method,get_route,1)

post_method='    def do_POST(self):\n'
post_route="""    def do_POST(self):
        if self.path.split("?",1)[0]=="/api/four-channel-production/run":
            try:
                _body=self.read_body()
                self.send_json(run_four_channel_production_qa(ROOT),200); return
            except Exception as e:
                self.send_json({"ok":False,"error":"4-Channel Production QA failed: "+str(e)},400); return
"""
if '/api/four-channel-production/run' not in text:
    if post_method not in text:
        raise RuntimeError("v1.14 do_POST anchor missing")
    text=text.replace(post_method,post_route,1)

text=text.replace('<div class="ver">v1.13.0</div>','<div class="ver">v1.14.10</div>')


# v1.14.8: preserve reasoning textarea as an actual DOM node across dashboard refreshes.
# This fixes both draft loss and the v1.14.7 focus/input regression. The node is detached
# before any render and reattached after render, so value, focus, selection and IME state
# are not reconstructed by a MutationObserver.
if "__lfStableResultBox" not in text:
    _stable_js = r"""<script>
window.__lfStableResultBox = null;
window.__lfStableResultParent = null;
window.__lfStableResultNext = null;

function lfHoldResultBox(){
  var box=document.getElementById("resultbox");
  if(!box) return;
  window.__lfStableResultBox=box;
  window.__lfStableResultParent=box.parentNode;
  window.__lfStableResultNext=box.nextSibling;
  box.remove();
}
function lfRestoreResultBox(){
  var box=window.__lfStableResultBox;
  if(!box) return;
  var fresh=document.getElementById("resultbox");
  if(!fresh) return;
  var parent=fresh.parentNode;
  fresh.replaceWith(box);
  window.__lfStableResultParent=parent;
  window.__lfStableResultNext=box.nextSibling;
}
</script>"""
    if "</body>" not in text:
        raise RuntimeError("v1.14.8 body anchor missing")
    text=text.replace("</body>",_stable_js+"</body>",1)

    # Wrap the dashboard's episode detail renderer(s), not global DOM mutation.
    # renderDetail is the canonical detail render function in this UI family.
    candidates=["async function renderDetail(", "function renderDetail(", "async function detail(", "function detail("]
    hit=None
    for c in candidates:
        if c in text:
            hit=c; break
    if hit:
        text=text.replace(hit, hit.replace("(", "(", 1), 1)
        # Add hold at function entry by locating its opening brace.
        pos=text.find(hit)
        brace=text.find("{",pos)
        text=text[:brace+1]+"lfHoldResultBox();try{"+text[brace+1:]
        # We cannot safely parse arbitrary JS to find function end here. Instead restoration
        # is scheduled synchronously at the end of the current task after render DOM writes.
        text=text[:brace+1]+"queueMicrotask(lfRestoreResultBox);"+text[brace+1:]
    else:
        # Stable fallback: preserve active textarea by preventing dashboard refresh while it
        # is being edited. Unlike v1.14.7 this never mutates/replaces the focused textarea.
        _guard = r"""<script>
document.addEventListener("focusin",function(e){
 if(e.target && e.target.id==="resultbox") document.documentElement.dataset.lfEditingResult="1";
},true);
document.addEventListener("focusout",function(e){
 if(e.target && e.target.id==="resultbox") delete document.documentElement.dataset.lfEditingResult;
},true);
</script>"""
        text=text.replace("</body>",_guard+"</body>",1)


# v1.14.9: do not re-render the dashboard while the AI result textarea owns focus.
# This is intentionally a refresh guard, not a DOM reconstruction workaround.
if "lfResultFocusGuard1149" not in text:
    old="async function refresh(){"
    new="async function refresh(){/*lfResultFocusGuard1149*/if(document.activeElement&&document.activeElement.id==='resultbox')return;"
    if old not in text:
        raise RuntimeError("v1.14.9 dashboard refresh anchor missing")
    text=text.replace(old,new,1)
# v1.14.10 Greenlight review support.
if "greenlight-review-11410" not in text:
    ui = '<script id="greenlight-review-11410">document.addEventListener("click",async function(ev){const b=ev.target.closest("[data-greenlight-decision]");if(!b)return;const id=b.dataset.episodeId,decision=b.dataset.greenlightDecision;const res=await fetch("/api/episodes/"+encodeURIComponent(id)+"/greenlight-review",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({decision:decision,note:""})});const j=await res.json().catch(()=>({}));if(!res.ok||j.ok===false){alert(j.error||j.message||"Greenlight review failed");return;}await refresh();},true);</script>'
    injector = '<script>function lfGreenlightButtons(){const title=[...document.querySelectorAll("h1,h2,h3")].find(x=>x.textContent.trim()==="Greenlight Review");if(!title||document.getElementById("greenlight-actions-11410"))return;const episode=(document.body.innerText.match(/JP_BTS_EP\\d+/)||[])[0];if(!episode)return;const box=document.createElement("div");box.id="greenlight-actions-11410";box.style.margin="12px 0";box.innerHTML=\'<button data-episode-id="\'+episode+\'" data-greenlight-decision="APPROVE">Approve Greenlight</button> <button data-episode-id="\'+episode+\'" data-greenlight-decision="HOLD">Hold</button> <button data-episode-id="\'+episode+\'" data-greenlight-decision="REJECT">Reject</button>\';title.insertAdjacentElement("afterend",box);}setInterval(lfGreenlightButtons,500);</script>'
    text=text.replace("</body>",ui+injector+"</body>",1)
    route_anchor="def do_POST(self):"
    if route_anchor not in text:
        raise RuntimeError("v1.14.10 do_POST anchor missing")
    pos=text.index(route_anchor)
    bodypos=text.find("\\n",pos)+1
    route = '        # greenlight-review-11410\\n        import re as _re\\n        _m=_re.fullmatch(r"/api/episodes/([^/]+)/greenlight-review", self.path.split("?",1)[0])\\n        if _m:\\n            try:\\n                import json as _json\\n                n=int(self.headers.get("Content-Length","0") or 0)\\n                body=_json.loads(self.rfile.read(n).decode("utf-8") or "{}")\\n                episode_id=_m.group(1)\\n                ep=ROOT/"projects"/"JP_BTS"/"episodes"/episode_id\\n                manifest=_json.loads((ep/"episode_manifest.json").read_text(encoding="utf-8"))\\n                from adapters.adapter_registry import get_adapter\\n                adapter=get_adapter(ROOT,manifest["authority"]["channel_adapter"])\\n                out=adapter.review_greenlight(episode_id,body.get("decision"),body.get("note",""))\\n                return self._json(200,out)\\n            except Exception as e:\\n                return self._json(400,{"ok":False,"error":str(e)})\\n'
    text=text[:bodypos]+route+text[bodypos:]
runtime=ROOT/"factory"/"state"/"control_center_v114_runtime.py"
runtime.parent.mkdir(parents=True,exist_ok=True)
runtime.write_text(text,encoding="utf-8")
runpy.run_path(str(runtime),run_name="__main__")
