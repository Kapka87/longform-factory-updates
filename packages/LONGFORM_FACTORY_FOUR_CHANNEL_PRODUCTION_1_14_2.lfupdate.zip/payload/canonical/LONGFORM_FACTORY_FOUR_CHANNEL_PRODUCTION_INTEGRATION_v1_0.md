# Longform Factory Four-Channel Production Integration v1.0

Status: RELEASE CANDIDATE
Target runtime: v1.14.0

Defaults after adoption:
- JP_STORY -> JP_STORY_REFERENCE_ADAPTER_v1_4
- EN_STORY -> EN_STORY_PRODUCTION_ADAPTER_v1_0
- EN_BTS -> EN_BTS_PRODUCTION_ADAPTER_v1_2
- JP_BTS -> JP_BTS_PRODUCTION_ADAPTER_v1_0

Principles:
- Existing Episode adapter pins win; no auto migration.
- Actual generated WAV is timeline authority.
- External SRT is default.
- Visual production remains provider-neutral unless explicitly bound.
- EN_STORY uses story-beat visual runs and fixed-frame Speaker Focus.
- EN_BTS uses BTS_CANONICAL_VISUAL_TEMPLATE_v1_1.
- JP_BTS resolves VOICEVOX roles dynamically from speaker/style names; hard-coded style IDs are forbidden.
- Publishing package must reach human approval before UPLOAD_READY.
- Four-channel production QA runs only under factory/_qa and must not modify real project manifests.
