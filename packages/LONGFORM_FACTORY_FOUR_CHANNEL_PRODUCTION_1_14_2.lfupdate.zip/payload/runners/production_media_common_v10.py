from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, math, re, shutil, subprocess, wave
import numpy as np

FPS=30
FINAL_SAMPLE_RATE=48000


def now(): return datetime.now(timezone.utc).isoformat()

def load(path,default=None):
    try: return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception: return {} if default is None else default

def save(path,obj):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+".tmp"); tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); tmp.replace(path)

def run(cmd,timeout=300,input_bytes=None):
    p=subprocess.run([str(x) for x in cmd],input=input_bytes,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
    if p.returncode!=0: raise RuntimeError("command failed: "+" ".join(map(str,cmd))+"\n"+p.stderr.decode("utf-8","replace")[-2400:])
    return p.stdout.decode("utf-8","replace")

def wav_info(path):
    with wave.open(str(path),"rb") as w:
        frames=w.getnframes(); sr=w.getframerate(); ch=w.getnchannels(); sw=w.getsampwidth()
    return {"frames":frames,"sample_rate":sr,"channels":ch,"sample_width":sw,"duration":frames/sr if sr else 0.0}

def read_pcm_mono(path):
    with wave.open(str(path),"rb") as w:
        sr=w.getframerate(); ch=w.getnchannels(); sw=w.getsampwidth(); raw=w.readframes(w.getnframes())
    if sw!=2: raise RuntimeError(f"Expected PCM16 WAV: {path}")
    a=np.frombuffer(raw,dtype="<i2").astype(np.float32)/32768.0
    if ch>1: a=a.reshape(-1,ch).mean(axis=1)
    return a,sr

def write_pcm16(path,audio,sr):
    a=np.clip(np.asarray(audio,dtype=np.float32).reshape(-1),-1,1); pcm=(a*32767.0).astype("<i2")
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    with wave.open(str(path),"wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(int(sr)); w.writeframes(pcm.tobytes())

def active_bounds(path,threshold=0.012,pad=0.035):
    a,sr=read_pcm_mono(path)
    if not len(a): return (0.0,0.0)
    idx=np.flatnonzero(np.abs(a)>=threshold)
    if not len(idx): return (0.0,len(a)/sr)
    lo=max(0.0,idx[0]/sr-pad); hi=min(len(a)/sr,(idx[-1]+1)/sr+pad)
    return lo,hi

def concat_voice(parts,pauses,out_pcm,out_final,ffmpeg):
    arrays=[]; offsets=[]; t=0.0; sr=None
    for i,(p,pause) in enumerate(zip(parts,pauses)):
        a,s=read_pcm_mono(p)
        if sr is None: sr=s
        if s!=sr: raise RuntimeError("Voice cue sample-rate mismatch")
        offsets.append(t); arrays.append(a); t+=len(a)/sr
        if pause>0:
            arrays.append(np.zeros(int(round(pause*sr)),dtype=np.float32)); t+=pause
    master=np.concatenate(arrays) if arrays else np.zeros(1,dtype=np.float32)
    write_pcm16(out_pcm,master,sr or 24000)
    Path(out_final).parent.mkdir(parents=True,exist_ok=True)
    run([ffmpeg,"-y","-hide_banner","-loglevel","error","-i",out_pcm,"-ar",str(FINAL_SAMPLE_RATE),"-ac","2",out_final],120)
    return wav_info(out_final),offsets

def srt_time(sec):
    ms=max(0,int(round(float(sec)*1000))); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def next_version(folder,prefix,suffix):
    folder=Path(folder); folder.mkdir(parents=True,exist_ok=True); best=0; rx=re.compile(re.escape(prefix)+r"v(\d+?)"+re.escape(suffix)+r"$")
    for p in folder.iterdir():
        m=rx.match(p.name)
        if m: best=max(best,int(m.group(1)))
    return best+1

def progress(ep,eid,stage,message,current=None,total=None,cache_hits=None,state="RUNNING"):
    p=Path(ep)/"work"/"job_status.json"; cur=load(p,{})
    cur.update({"episode_id":eid,"job":cur.get("job") or "BUILD_PREVIEW","state":state,"stage":stage,"message":message,"updated_at":now()})
    if current is not None: cur["item_current"]=current
    if total is not None: cur["item_total"]=total
    if cache_hits is not None: cur["cache_hits"]=cache_hits
    save(p,cur)

def set_stage(m,stage,state,current=False):
    lc=m.setdefault("lifecycle",{}); it=lc.setdefault("stages",{}).setdefault(stage,{}); it["runtime_state"]=state; it["updated_at"]=now()
    if current: lc["current_stage"]=stage

def focus_image(source,box,out_path,dim=0.60,feather=80):
    from PIL import Image, ImageFilter
    source=Path(source); out_path=Path(out_path); out_path.parent.mkdir(parents=True,exist_ok=True)
    with Image.open(source).convert("RGB") as im:
        if im.size!=(1920,1080): raise RuntimeError(f"Visual must be 1920x1080: {source.name}")
        mask=Image.new("L",im.size,int(round(255*dim)))
        from PIL import ImageDraw
        d=ImageDraw.Draw(mask); x0,y0,x1,y1=[int(round(float(x))) for x in box]; d.rectangle((x0,y0,x1,y1),fill=0)
        mask=mask.filter(ImageFilter.GaussianBlur(radius=feather))
        black=Image.new("RGB",im.size,(0,0,0)); out=Image.composite(black,im,mask); out.save(out_path)
    return out_path

def render_static_or_push(ffmpeg,image,duration,out,motion="STATIC"):
    duration=max(0.05,float(duration)); out=Path(out); out.parent.mkdir(parents=True,exist_ok=True); motion=str(motion or "STATIC").upper()
    if motion=="STATIC":
        vf="fps=30,format=yuv420p"
    elif motion=="SLOW_PUSH":
        # Continuous visual-run motion. No FFmpeg zoompan. 3% max push with smoothstep and Lanczos resampling.
        D=max(duration,0.05)
        x=f"min(max(t/{D:.6f},0),1)"; ease=f"(3*({x})*({x})-2*({x})*({x})*({x}))"; scale=f"(1+0.03*{ease})"
        vf=(f"scale=w='trunc(1920*{scale}/2)*2':h='trunc(1080*{scale}/2)*2':eval=frame:flags=lanczos,"+"crop=1920:1080:(iw-1920)/2:(ih-1080)/2,fps=30,format=yuv420p")
    else: raise RuntimeError("Unsupported motion: "+motion)
    run([ffmpeg,"-y","-hide_banner","-loglevel","error","-loop","1","-framerate","30","-i",image,"-t",f"{duration:.6f}","-vf",vf,"-c:v","libx264","-preset","veryfast","-pix_fmt","yuv420p",out],max(120,int(duration*3+30)))

def render_focus_run(ffmpeg,image,run_lines,line_durations,speakers,regions,cache_dir,out,crossfade=0.25):
    # Underlying source is fixed. Only deterministic dim-rest focus state changes.
    groups=[]
    for idx in run_lines:
        sp=speakers[idx-1]; dur=float(line_durations[idx-1])
        if groups and groups[-1][0]==sp: groups[-1][1]+=dur
        else: groups.append([sp,dur])
    if not groups: raise RuntimeError("Speaker Focus run has no lines")
    clips=[]
    for i,(sp,dur) in enumerate(groups):
        box=regions.get(sp)
        if box is None: raise RuntimeError(f"Speaker Focus region missing for {sp}")
        state=focus_image(image,box,Path(cache_dir)/f"focus_{Path(image).stem}_{hashlib.sha1(sp.encode()).hexdigest()[:8]}.png")
        # Extend clips after the first by overlap duration; xfade removes the overlap and preserves original total.
        clipdur=dur+(crossfade if i>0 else 0.0)
        clip=Path(cache_dir)/f"focusclip_{Path(image).stem}_{i:02d}.mp4"; render_static_or_push(ffmpeg,state,clipdur,clip,"STATIC"); clips.append((clip,dur))
    if len(clips)==1: shutil.copy2(clips[0][0],out); return
    cmd=[ffmpeg,"-y","-hide_banner","-loglevel","error"]
    for p,_ in clips: cmd += ["-i",p]
    chains=[]; cumulative=clips[0][1]; last="[0:v]"
    for i in range(1,len(clips)):
        label=f"[x{i}]"; offset=max(0.0,cumulative-crossfade); chains.append(f"{last}[{i}:v]xfade=transition=fade:duration={crossfade:.6f}:offset={offset:.6f}{label}"); last=label; cumulative+=clips[i][1]
    run(cmd+["-filter_complex",";".join(chains),"-map",last,"-an","-c:v","libx264","-preset","veryfast","-pix_fmt","yuv420p",out],max(120,int(cumulative*4+30)))

def render_visual_timeline(ffmpeg,visual_dir,mapping,line_durations,speakers,cache_dir,out):
    visual_dir=Path(visual_dir); cache_dir=Path(cache_dir); cache_dir.mkdir(parents=True,exist_ok=True)
    visuals={str(v.get("id")):v for v in mapping.get("visuals",[]) if isinstance(v,dict)}; segments=[]
    for ri,r in enumerate(mapping.get("runs",[]),1):
        vid=str(r.get("visual_id") or ""); v=visuals.get(vid); a=int(r.get("line_start",0)); b=int(r.get("line_end",0))
        if not v or a<1 or b<a or b>len(line_durations): raise RuntimeError("Invalid visual run")
        image=visual_dir/str(v.get("filename") or "")
        if not image.exists(): raise RuntimeError(f"Visual missing: {image.name}")
        duration=sum(float(x) for x in line_durations[a-1:b]); seg=cache_dir/f"run_{ri:03d}.mp4"
        if bool(r.get("speaker_focus",False)):
            if str(r.get("motion") or "STATIC").upper()!="STATIC": raise RuntimeError("Speaker Focus requires fixed STATIC underlying frame")
            render_focus_run(ffmpeg,image,list(range(a,b+1)),line_durations,speakers,r.get("speaker_regions") or {},cache_dir,seg)
        else: render_static_or_push(ffmpeg,image,duration,seg,r.get("motion") or "STATIC")
        segments.append(seg)
    concat=cache_dir/"visual_runs.ffconcat"; rows=["ffconcat version 1.0"]
    def esc(p): return str(p).replace("'","'\\''")
    for p in segments: rows.append(f"file '{esc(p)}'")
    concat.write_text("\n".join(rows)+"\n",encoding="utf-8")
    run([ffmpeg,"-y","-hide_banner","-loglevel","error","-f","concat","-safe","0","-i",concat,"-c","copy",out],300)

def finalize_preview(ffmpeg,ffprobe,silent,master,preview):
    run([ffmpeg,"-y","-hide_banner","-loglevel","error","-i",silent,"-i",master,"-c:v","copy","-c:a","aac","-b:a","192k","-ar",str(FINAL_SAMPLE_RATE),"-ac","2","-shortest","-movflags","+faststart",preview],300)
    probe=json.loads(run([ffprobe,"-v","error","-show_entries","format=duration:stream=width,height,codec_type,codec_name","-of","json",preview],60))
    return probe
