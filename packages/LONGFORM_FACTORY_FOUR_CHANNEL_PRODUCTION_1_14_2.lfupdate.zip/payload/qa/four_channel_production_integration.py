#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import copy, hashlib, json, shutil, subprocess, sys, traceback, urllib.request

ROOT=Path(__file__).resolve().parents[2]
FACTORY=ROOT/"factory"
if str(FACTORY) not in sys.path: sys.path.insert(0,str(FACTORY))
from shared_core.adapter_runtime import AdapterManager
from shared_core.stage_job_engine import StageJobEngine

REPORT=FACTORY/"state"/"four_channel_production_qa.json"
SANDBOX=FACTORY/"_qa"/"four_channel_production"/"sandbox_root"
STAGES=["DISCOVERY","GREENLIGHT","RESEARCH","FACT_LOCK","SCRIPT","SCRIPT_QC","VISUAL_PLAN","VISUAL_BUILD","VISUAL_QC","VOICE","TIMING","SUBTITLES","EDIT_PLAN","RENDER","AUTO_QC","PREVIEW_REVIEW","FINAL","THUMBNAIL","TITLE","DESCRIPTION","TAGS","PUBLISHING_QC","PUBLISHING_REVIEW","UPLOAD_READY"]
EXPECTED={
 "JP_STORY":("JP_STORY_v1","JP_STORY_REFERENCE_ADAPTER_v1_4"),
 "EN_STORY":("EN_DRAMA_v1","EN_STORY_PRODUCTION_ADAPTER_v1_0"),
 "EN_BTS":("EN_TECH_v1","EN_BTS_PRODUCTION_ADAPTER_v1_2"),
 "JP_BTS":("JP_TECH_v1","JP_BTS_PRODUCTION_ADAPTER_v1_0"),
}

def sha(p):
    h=hashlib.sha256();
    with Path(p).open("rb") as f:
        for c in iter(lambda:f.read(1024*1024),b""): h.update(c)
    return h.hexdigest()
def manifests(): return {str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/"projects").glob("*/episodes/*/episode_manifest.json"))}
def save(p,x): p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def stage_manifest(channel,profile,aid,eid,num):
    stages={s:{"runtime_state":"NOT_STARTED","human_checkpoint":s in {"GREENLIGHT","SCRIPT_QC","VISUAL_QC","PREVIEW_REVIEW","PUBLISHING_REVIEW"}} for s in STAGES}
    for s in ["DISCOVERY","GREENLIGHT","RESEARCH","FACT_LOCK","SCRIPT","SCRIPT_QC","VISUAL_PLAN","VISUAL_BUILD","VISUAL_QC"]: stages[s]["runtime_state"]="COMPLETE"
    stages["VOICE"]["runtime_state"]="READY"
    return {"schema_version":"1.2","channel_id":channel,"episode_number":num,"episode_id":eid,"profile":profile,"authority":{"channel_adapter":aid},"lifecycle":{"model":"IDEA_TO_UPLOAD_READY_v1","state":"ACTIVE","current_stage":"VOICE","stages":stages},"script":{"status":"FINAL_LOCK"},"visuals":{"status":"FINAL_LOCK"},"workstreams":{"script":{"status":"FINAL_LOCK"},"visuals":{"status":"FINAL_LOCK"}},"publishing":{"status":"DRAFT"}}
def make_dirs(ep):
    for rel in ["input/script","input/visuals","input/config","work/visual_mapping","work/voice","work/timing","work/srt","work/render_cache","output/preview","output/final","output/publishing"]: (ep/rel).mkdir(parents=True,exist_ok=True)
def font(n):
    from PIL import ImageFont
    for p in ["/System/Library/Fonts/Supplemental/Arial.ttf","/System/Library/Fonts/Supplemental/Arial Bold.ttf","/System/Library/Fonts/ヒラギノ角ゴシック W3.ttc"]:
        if Path(p).exists():
            try:return ImageFont.truetype(p,n)
            except Exception: pass
    return ImageFont.load_default()
def qa_visual(path,title,sub,left_right=False):
    from PIL import Image,ImageDraw
    im=Image.new("RGB",(1920,1080),(244,245,247)); d=ImageDraw.Draw(im)
    if left_right:
        d.rectangle((80,100,900,790),fill=(219,225,232)); d.rectangle((1020,100,1840,790),fill=(229,224,219)); d.text((270,390),"HEART",fill=(35,40,48),font=font(60)); d.text((1250,390),"LIAM",fill=(35,40,48),font=font(60))
    d.text((140,110),title,fill=(20,22,28),font=font(64)); d.text((140,760),sub,fill=(70,74,82),font=font(30)); im.save(path)
def voicevox_speakers():
    with urllib.request.urlopen("http://127.0.0.1:50021/speakers",timeout=3) as r: return json.loads(r.read().decode("utf-8"))

def run_job(mgr,ep,m):
    eng=StageJobEngine(SANDBOX,mgr); enq=eng.enqueue_adapter_job(ep,m,"BUILD_PREVIEW")
    if not enq.get("ok"): raise RuntimeError("enqueue failed: "+repr(enq))
    job=eng.claim_next()
    if not job: raise RuntimeError("claim failed")
    proc,logf,started=eng.start_claimed(job)
    try: rc=proc.wait(timeout=300)
    finally:
        try: logf.close()
        except Exception: pass
    finished=eng.finish(started["job_id"],rc)
    if rc!=0: raise RuntimeError("runner failed: "+repr(finished))
    return finished

def complete_preview_and_publishing(mgr,ep):
    m=load(ep/"episode_manifest.json"); out=mgr.invoke_action(ep,m,"approve_preview",{})
    if not out.get("ok"): raise RuntimeError("preview approval failed")
    m=load(ep/"episode_manifest.json"); eid=m["episode_id"]
    from PIL import Image,ImageDraw
    thumb=Image.new("RGB",(1280,720),(235,236,239)); d=ImageDraw.Draw(thumb); d.text((80,260),eid,fill=(20,20,24),font=font(52)); thumb.save(ep/"output"/"publishing"/f"{eid}_THUMBNAIL_FINAL.png")
    m=load(ep/"episode_manifest.json")
    pub=ep/"output"/"publishing"
    (pub/f"{eid}_TITLE.txt").write_text("QA title\n",encoding="utf-8"); (pub/f"{eid}_DESCRIPTION.txt").write_text("QA description\n",encoding="utf-8"); (pub/f"{eid}_TAGS.txt").write_text("qa, integration\n",encoding="utf-8")
    for st in ["TITLE","DESCRIPTION","TAGS"]: m["lifecycle"]["stages"][st]["runtime_state"]="COMPLETE"
    m["lifecycle"]["current_stage"]="PUBLISHING_QC"; m["lifecycle"]["stages"]["PUBLISHING_QC"]["runtime_state"]="NEEDS_REVIEW"; save(ep/"episode_manifest.json",m)
    done=mgr.invoke_action(ep,m,"approve_publishing",{})
    if not done.get("ok"): raise RuntimeError("publishing approval failed")
    return load(ep/"episode_manifest.json")

def fixture_en_story(ep):
    make_dirs(ep); eid="EN_STORY_EP996"
    script={"schema":"EN_STORY_PRODUCTION_SCRIPT_v1","casting":{"HEART":{"voice":"af_heart","speed":0.96},"LIAM":{"voice":"am_liam","speed":0.92}},"lines":[
      {"id":"L001","speaker":"HEART","text":"You came back earlier than I expected.","subtitle_text":"You came back earlier\nthan I expected.","pause_after":0.25},
      {"id":"L002","speaker":"LIAM","text":"I almost didn't.","subtitle_text":"I almost didn't.","pause_after":0.30},
      {"id":"L003","speaker":"HEART","text":"Then tell me why you're here.","subtitle_text":"Then tell me why you're here.","pause_after":0.25},
      {"id":"L004","speaker":"LIAM","text":"Because leaving was the mistake.","subtitle_text":"Because leaving was the mistake.","pause_after":0.20}]}
    save(ep/"input/script"/f"{eid}_SCRIPT_FINAL.json",script); (ep/"input/script"/f"{eid}_SCRIPT_FINAL.txt").write_text("\n".join(f"{x['speaker']}: {x['text']}" for x in script["lines"])+"\n",encoding="utf-8")
    fn=f"{eid}_V01_MASTER_1920x1080.png"; qa_visual(ep/"input/visuals"/fn,"EN_STORY QA","Speaker Focus · fixed underlying frame",True)
    mapping={"schema":"EN_STORY_VISUAL_MAPPING_v1","visuals":[{"id":"V01","filename":fn,"role":"TWO_SHOT"}],"runs":[{"visual_id":"V01","line_start":1,"line_end":4,"motion":"STATIC","speaker_focus":True,"speaker_regions":{"HEART":[80,100,900,790],"LIAM":[1020,100,1840,790]}}]}; save(ep/"work/visual_mapping"/f"{eid}_VISUAL_MAPPING_v01.json",mapping)
    m=stage_manifest("EN_STORY","EN_DRAMA_v1","EN_STORY_PRODUCTION_ADAPTER_v1_0",eid,996); save(ep/"episode_manifest.json",m); return m

def fixture_en_bts(ep):
    make_dirs(ep); eid="EN_BTS_EP995"
    script="V01\nA queue can move without assigning inventory.\n\nV02\nSeveral gates may run before an offer appears.\n"; (ep/"input/script"/f"{eid}_SCRIPT_FINAL.txt").write_text(script,encoding="utf-8")
    visuals=[]
    for i,title in enumerate(["QUEUE STATE","ACCESS GATES"],1):
        fn=f"{eid}_V{i:02d}_MASTER_1920x1080.png"; qa_visual(ep/"input/visuals"/fn,title,"EN_BTS QA · subtitle-safe"); visuals.append({"id":f"V{i:02d}","template":"A_SEQUENCE_SYSTEM","filename":fn,"message":title,"method":"DETERMINISTIC"})
    mapping={"schema":"EN_BTS_VISUAL_MAPPING_v1","visuals":visuals,"runs":[{"visual_id":"V01","beat_start":1,"beat_end":1},{"visual_id":"V02","beat_start":2,"beat_end":2}]}; save(ep/"work/visual_mapping"/f"{eid}_VISUAL_MAPPING_v01.json",mapping)
    m=stage_manifest("EN_BTS","EN_TECH_v1","EN_BTS_PRODUCTION_ADAPTER_v1_2",eid,995); save(ep/"episode_manifest.json",m); return m

def fixture_jp_bts(ep):
    make_dirs(ep); eid="JP_BTS_EP994"; speakers=voicevox_speakers(); choices=[]
    for sp in speakers:
        styles=sp.get("styles") or []
        if styles: choices.append((str(sp.get("name")),str(styles[0].get("name"))))
        if len(choices)>=2: break
    if not choices: raise RuntimeError("VOICEVOX returned no speaker/style")
    if len(choices)==1: choices.append(choices[0])
    script={"schema":"JP_BTS_PRODUCTION_SCRIPT_v1","casting":{"A":{"speaker_name":choices[0][0],"style_name":choices[0][1],"gender":"male"},"B":{"speaker_name":choices[1][0],"style_name":choices[1][1],"gender":"male"}},"lines":[
      {"id":"L001","speaker":"A","text":"早く入っても、一番とは限りません。","spoken_text":"早く入っても、一番とは限りません。","subtitle_text":"早く入っても\n一番とは限りません。","pause_after":0.25},
      {"id":"L002","speaker":"B","text":"順番の前に、別の処理があります。","spoken_text":"順番の前に、別の処理があります。","subtitle_text":"順番の前に\n別の処理があります。","pause_after":0.25},
      {"id":"L003","speaker":"A","text":"だから、表示だけでは判断できません。","spoken_text":"だから、表示だけでは判断できません。","subtitle_text":"表示だけでは\n判断できません。","pause_after":0.20}]}
    save(ep/"input/script"/f"{eid}_SCRIPT_FINAL.json",script); (ep/"input/script"/f"{eid}_SCRIPT_FINAL.txt").write_text("\n".join(x["text"] for x in script["lines"])+"\n",encoding="utf-8")
    visuals=[]
    for i,title in enumerate(["JP_BTS QA 1","JP_BTS QA 2"],1):
        fn=f"{eid}_V{i:02d}_MASTER_1920x1080.png"; qa_visual(ep/"input/visuals"/fn,title,"structured information beat"); visuals.append({"id":f"V{i:02d}","filename":fn,"role":"SYSTEM"})
    mapping={"schema":"JP_BTS_VISUAL_MAPPING_v1","visuals":visuals,"runs":[{"visual_id":"V01","line_start":1,"line_end":2,"motion":"STATIC"},{"visual_id":"V02","line_start":3,"line_end":3,"motion":"STATIC"}]}; save(ep/"work/visual_mapping"/f"{eid}_VISUAL_MAPPING_v01.json",mapping)
    m=stage_manifest("JP_BTS","JP_TECH_v1","JP_BTS_PRODUCTION_ADAPTER_v1_0",eid,994); save(ep/"episode_manifest.json",m); return m

def run_four_channel_production_qa(root=None):
    global ROOT, FACTORY, REPORT, SANDBOX
    if root is not None:
        ROOT=Path(root).resolve(); FACTORY=ROOT/"factory"; REPORT=FACTORY/"state"/"four_channel_production_qa.json"; SANDBOX=FACTORY/"_qa"/"four_channel_production"/"sandbox_root"
    before=manifests(); checks=[]
    def ck(name,ok,detail=""):
        checks.append({"name":name,"status":"PASS" if ok else "FAIL","detail":str(detail)})
        if not ok: raise AssertionError(f"{name}: {detail}")
    try:
        if SANDBOX.exists(): shutil.rmtree(SANDBOX)
        (SANDBOX/"factory/adapters").mkdir(parents=True,exist_ok=True); (SANDBOX/"factory/state").mkdir(parents=True,exist_ok=True); (SANDBOX/"factory/runners").mkdir(parents=True,exist_ok=True)
        shutil.copy2(FACTORY/"adapters"/"adapter_registry.json",SANDBOX/"factory/adapters"/"adapter_registry.json")
        for fn in ["production_media_common_v10.py","en_story_production_media_v10.py","en_bts_production_media_v10.py","jp_bts_production_media_v10.py"]: shutil.copy2(FACTORY/"runners"/fn,SANDBOX/"factory/runners"/fn)
        smoke=load(FACTORY/"state"/"cross_channel_media_smoke.json"); save(SANDBOX/"factory/state/cross_channel_media_smoke.json",smoke)
        mgr=AdapterManager(SANDBOX); reg=mgr.registry(); ck("Adapter registry v2.0",reg.get("registry_version")=="2.0",reg.get("registry_version"))
        for cid,(profile,aid) in EXPECTED.items():
            manifest={"schema_version":"1.2","channel_id":cid,"profile":profile,"episode_id":cid+"_EP999","authority":{},"lifecycle":{"current_stage":"DISCOVERY"}}
            resolved=mgr.adapter_id_for_manifest(manifest); ck(cid+" default dispatch",resolved==aid,resolved)
        for cid in ("EN_STORY","EN_BTS","JP_BTS"): ck(cid+" representative smoke retained",smoke.get("channels",{}).get(cid,{}).get("status")=="PASS",smoke.get("channels",{}).get(cid,{}).get("status"))
        fixtures=[("EN_STORY",SANDBOX/"projects/EN_STORY/episodes/EN_STORY_EP996",fixture_en_story),("EN_BTS",SANDBOX/"projects/EN_BTS/episodes/EN_BTS_EP995",fixture_en_bts),("JP_BTS",SANDBOX/"projects/JP_BTS/episodes/JP_BTS_EP994",fixture_jp_bts)]
        for cid,ep,fn in fixtures:
            m=fn(ep); pf=mgr.preflight(ep,m,"RENDER"); ck(cid+" production preflight",pf.get("pass") is True,pf)
            run_job(mgr,ep,m)
            qcs=sorted((ep/"output/preview").glob("*_QC_v*.json")); ck(cid+" actual media QC",bool(qcs) and load(qcs[-1]).get("status")=="PASS",load(qcs[-1]) if qcs else "missing")
            m2=load(ep/"episode_manifest.json"); ck(cid+" reaches Preview Review",m2.get("lifecycle",{}).get("current_stage")=="PREVIEW_REVIEW",m2.get("lifecycle",{}).get("current_stage"))
            done=complete_preview_and_publishing(mgr,ep); ck(cid+" reaches UPLOAD_READY",done.get("lifecycle",{}).get("current_stage")=="UPLOAD_READY" and done.get("lifecycle",{}).get("state")=="COMPLETE",done.get("lifecycle",{}))
        after=manifests(); ck("Real project manifests untouched",before==after,f"before={len(before)} after={len(after)}")
        status="PASS"
    except Exception as e:
        status="FAIL"; checks.append({"name":"Unhandled exception","status":"FAIL","detail":str(e)}); traceback.print_exc()
    report={"schema":"LONGFORM_FACTORY_FOUR_CHANNEL_PRODUCTION_QA_v1","created_at":datetime.now(timezone.utc).isoformat(),"status":status,"checks":checks,"sandbox":str(SANDBOX.relative_to(ROOT)),"defaults":EXPECTED}
    save(REPORT,report); return report

def four_channel_production_status(root=None):
    r=Path(root).resolve() if root is not None else ROOT; p=r/"factory/state/four_channel_production_qa.json"
    if not p.exists(): return {"schema":"LONGFORM_FACTORY_FOUR_CHANNEL_PRODUCTION_QA_v1","status":"NOT_RUN","checks":[]}
    try:return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:return {"status":"FAIL","checks":[{"name":"Report read","status":"FAIL","detail":str(e)}]}

if __name__=="__main__":
    report=run_four_channel_production_qa(); print(json.dumps(report,ensure_ascii=False,indent=2)); raise SystemExit(0 if report.get("status")=="PASS" else 1)
