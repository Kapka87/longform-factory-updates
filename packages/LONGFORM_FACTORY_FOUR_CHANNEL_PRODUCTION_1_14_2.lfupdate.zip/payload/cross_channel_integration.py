from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json
from shared_core.adapter_runtime import AdapterManager, AdapterError
EXPECTED={"JP_STORY":("JP_STORY_v1","JP_STORY_REFERENCE_ADAPTER_v1_4"),"EN_STORY":("EN_DRAMA_v1","EN_STORY_PRODUCTION_ADAPTER_v1_0"),"EN_BTS":("EN_TECH_v1","EN_BTS_PRODUCTION_ADAPTER_v1_2"),"JP_BTS":("JP_TECH_v1","JP_BTS_PRODUCTION_ADAPTER_v1_0")}
def _m(cid,p):return {"schema_version":"1.2","channel_id":cid,"profile":p,"episode_id":cid+"_EP999","authority":{},"lifecycle":{"current_stage":"DISCOVERY"}}
def _media(root):
 p=Path(root)/"factory/state/cross_channel_media_smoke.json"
 try:return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
 except Exception:return {}
def run_cross_channel_qa(root):
 a=AdapterManager(Path(root)); checks=[]; matrix={}
 def add(n,ok,d=""):checks.append({"name":n,"status":"PASS" if ok else "FAIL","detail":str(d)})
 reg=a.registry(); add("Registry version",reg.get("registry_version")=="2.0",reg.get("registry_version"))
 for cid,(p,aid) in EXPECTED.items():
  m=_m(cid,p)
  try:
   resolved=a.adapter_id_for_manifest(m); desc=a.describe(m); add(cid+" default dispatch",resolved==aid and desc.get("channel_id")==cid and desc.get("profile_id")==p,f"{resolved} · {desc.get('integration_status','ACTIVE')}"); matrix[cid]=desc
  except Exception as e:add(cid+" default dispatch",False,e);continue
  bad=_m(cid,"WRONG_PROFILE_v0"); rejected=False
  try:a.describe(bad)
  except AdapterError:rejected=True
  add(cid+" profile isolation",rejected,"wrong profile rejected" if rejected else "wrong profile accepted")
 bad=_m("EN_STORY","EN_DRAMA_v1"); bad["authority"]["channel_adapter"]="JP_BTS_PRODUCTION_ADAPTER_v1_0"; rejected=False
 try:a.describe(bad)
 except AdapterError:rejected=True
 add("Pinned adapter/channel isolation",rejected,"cross-channel pin rejected" if rejected else "cross-channel pin accepted")
 add("JP legacy compatibility preserved",reg.get("channels",{}).get("JP_STORY",{}).get("legacy_default_adapter")=="JP_STORY_LEGACY_MEDIA_ADAPTER_v1_2",reg.get("channels",{}).get("JP_STORY",{}).get("legacy_default_adapter"))
 smoke=_media(root); false=[]
 for cid in ("EN_STORY","EN_BTS","JP_BTS"):
  if matrix.get(cid,{}).get("media_binding")=="ACTIVE_MEDIA_SMOKE" and smoke.get("channels",{}).get(cid,{}).get("status")!="PASS":false.append(cid)
 add("No false media-complete claims",not false,"none" if not false else ",".join(false))
 out={"schema":"LONGFORM_FACTORY_CROSS_CHANNEL_QA_v2","created_at":datetime.now(timezone.utc).isoformat(),"state":"PASS" if all(x["status"]=="PASS" for x in checks) else "FAIL","checks":checks,"matrix":matrix,"media_smoke":smoke.get("channels",{})}
 p=Path(root)/"factory/state/cross_channel_qa.json"; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); return out
