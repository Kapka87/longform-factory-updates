from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import importlib.util
import json
import shutil
import sys

from adapters.channels.en_bts.production_adapter_v10 import (
    ENBTSProductionAdapter as ENBTSProductionAdapterV10,
    _find_key,
    _read,
    _write,
)

MEDIA_REASONING_INSTRUCTIONS = {
    "VISUAL_PLAN": """Plan EN_BTS visuals from the FINAL script using BTS_CANONICAL_VISUAL_TEMPLATE_v1_1. Return JSON only using the installed reasoning result schema. Put one visual_mapping object inside decisions[]. The visual_mapping must be: {schema:'EN_BTS_VISUAL_MAPPING_v1', visuals:[{id:'V01', template:'A_SEQUENCE_SYSTEM|B_COMPARE_CONTRAST|C_EDITORIAL_HUMAN_CONTEXT', filename:'<final 1920x1080 PNG basename>', message:'<one core message>', method:'DETERMINISTIC|PROVIDER_NEUTRAL_SOURCE_RENDER_PLUS_DETERMINISTIC_FINALIZER'}], runs:[{visual_id:'V01', beat_start:1, beat_end:1}]}. Beat numbers refer to blank-line-separated spoken beats in the FINAL script after removing standalone V## marker lines. Every beat must be covered exactly once. Prefer reuse before new assets. Containerless is default. No arrows, connector lines, flowchart paths, decorative cards/panels/badges. Template C is provider-neutral and generated images are SOURCE_RENDER only; exact text/numbers/UI-like information must be finalized deterministically. Keep critical information above y=820. Do not invent private/non-public system mechanics or visually strengthen qualifiers.""",
    "VISUAL_QC": """QC the imported EN_BTS final visual masters against BTS_CANONICAL_VISUAL_TEMPLATE_v1_1 and the locked visual mapping. Verify script alignment, factual scope, A/B/C family correctness, containerless default, no arrows/connectors/flowchart paths, text density, subtitle-safe placement, hierarchy, exact 1920x1080 pixels, no unauthorized logo/brand UI, and preservation of claim qualifiers. Return PASS only when the complete imported set is suitable for human FINAL LOCK review.""",
}

MEDIA_STAGES={"VOICE","TIMING","SUBTITLES","EDIT_PLAN","RENDER","AUTO_QC","PREVIEW_REVIEW","FINAL"}

def _now():
    return datetime.now(timezone.utc).isoformat()

def _locked(v):
    return str(v or "").upper().replace(" ","_") in {"LOCK","FINAL_LOCK","FINAL"}

class ENBTSProductionAdapter(ENBTSProductionAdapterV10):
    ADAPTER_ID="EN_BTS_PRODUCTION_ADAPTER_v1_1"
    DISPLAY_NAME="Between the Steps — Production Media Candidate"

    def describe(self, context):
        out=super().describe(context)
        out.update({
            "adapter_id":self.ADAPTER_ID,
            "adapter_version":"1.1",
            "production_status":"MEDIA_CANDIDATE",
            "integration_status":"PRODUCTION_MEDIA_CANDIDATE",
        })
        caps=json.loads(json.dumps(out.get("capabilities",{})))
        caps.setdefault("media",{}).update({
            "runner":"EN_BTS_PRODUCTION_MEDIA_v1",
            "preview":"ACTUAL_KOKORO_WAV_PLUS_IMPORTED_LOCKED_VISUALS",
            "render":"FFMPEG_H264_AAC_1920x1080",
            "subtitle_alignment":"ACTUAL_AUDIO_ACTIVITY",
            "cache":"PER_BEAT_VOICE_HASH",
        })
        out["capabilities"]=caps
        return out

    def _mapping_path(self, ep, manifest):
        d=Path(ep)/"work"/"visual_mapping"
        xs=sorted(d.glob(f"{manifest.get('episode_id')}_VISUAL_MAPPING_v*.json")) if d.exists() else []
        return xs[-1] if xs else d/f"{manifest.get('episode_id')}_VISUAL_MAPPING_v01.json"

    def _visual_dir(self, ep):
        return Path(ep)/"input"/"visuals"

    def _preview_qc(self, ep, manifest):
        d=Path(ep)/"output"/"preview"
        xs=sorted(d.glob(f"{manifest.get('episode_id')}_QC_v*.json")) if d.exists() else []
        return _read(xs[-1],{}) if xs else {}

    def _script_status(self, m):
        return m.get("script",{}).get("status") or m.get("workstreams",{}).get("script",{}).get("status") or ""

    def _visual_status(self, m):
        return m.get("visuals",{}).get("status") or m.get("workstreams",{}).get("visuals",{}).get("status") or ""

    def _expected_visuals(self, ep, manifest):
        mapping=_read(self._mapping_path(ep,manifest),{})
        rows=[]
        for v in mapping.get("visuals",[]) if isinstance(mapping,dict) else []:
            if not isinstance(v,dict): continue
            fn=str(v.get("filename") or "").strip()
            if fn:
                rows.append((str(v.get("id") or ""), fn, v))
        return mapping,rows

    def preflight(self, stage, context):
        base=super().preflight(stage,context)
        m=self._context_manifest(context); ep=self._context_ep(context)
        checks=list(base.get("checks",[]))
        # V10 checks its dynamic self.ADAPTER_ID, so the v1.1 pin is enforced.
        if stage in MEDIA_STAGES:
            vs=self._visual_status(m)
            checks.append({"name":"Visual FINAL LOCK","pass":_locked(vs),"detail":vs or "missing"})
            mp=self._mapping_path(ep,m)
            checks.append({"name":"Visual Mapping","pass":mp.exists(),"detail":str(mp)})
            mapping,rows=self._expected_visuals(ep,m)
            missing=[]
            for _,fn,_ in rows:
                if not (self._visual_dir(ep)/fn).exists(): missing.append(fn)
            checks.append({"name":"Locked visual files","pass":bool(rows) and not missing,"detail":"ok" if rows and not missing else ("missing: "+", ".join(missing) if missing else "mapping has no visuals")})
            checks.append({"name":"Kokoro","pass":importlib.util.find_spec("kokoro") is not None,"detail":"available" if importlib.util.find_spec("kokoro") else "missing"})
            checks.append({"name":"ffmpeg","pass":bool(shutil.which("ffmpeg")),"detail":shutil.which("ffmpeg") or "missing"})
            checks.append({"name":"ffprobe","pass":bool(shutil.which("ffprobe")),"detail":shutil.which("ffprobe") or "missing"})
        return {"pass":all(bool(x.get("pass")) for x in checks),"checks":checks,"resource_class":"HEAVY_RENDER" if stage in MEDIA_STAGES else base.get("resource_class",self._resource_class(stage))}

    def _create_task(self, ep, manifest):
        stage=self._stage(manifest)
        if stage not in MEDIA_REASONING_INSTRUCTIONS:
            return super()._create_task(ep,manifest)
        existing=self._load_task(ep,stage)
        if existing and existing.get("status")=="AWAITING_MANUAL_RESULT":
            return {"ok":True,"message":"Existing task reused","task_id":existing.get("task_id")}
        import reasoning_provider_bridge as reasoning
        instruction=MEDIA_REASONING_INSTRUCTIONS[stage]
        packet=reasoning.execute_task(self.root,task={
            "task_type":f"EN_BTS_{stage}","channel_id":self.CHANNEL_ID,
            "episode_id":manifest.get("episode_id"),"instruction":instruction,
            "context":self._task_context(ep,manifest,stage),
        })
        _write(self._task_copy(ep,stage),packet)
        self._set_stage(manifest,stage,"BLOCKED",current=True)
        self._save_manifest(ep,manifest)
        return {"ok":True,"message":"Reasoning task prepared","task_id":packet.get("task_id")}

    def _validate_mapping(self, mapping, beat_count=None):
        if not isinstance(mapping,dict) or mapping.get("schema")!="EN_BTS_VISUAL_MAPPING_v1":
            raise ValueError("visual_mapping.schema must be EN_BTS_VISUAL_MAPPING_v1")
        visuals=mapping.get("visuals"); runs=mapping.get("runs")
        if not isinstance(visuals,list) or not visuals: raise ValueError("visual_mapping.visuals required")
        if not isinstance(runs,list) or not runs: raise ValueError("visual_mapping.runs required")
        ids=set()
        for v in visuals:
            if not isinstance(v,dict): raise ValueError("visual item must be object")
            vid=str(v.get("id") or "").strip(); fn=str(v.get("filename") or "").strip()
            if not vid or not fn: raise ValueError("visual id and filename required")
            if Path(fn).name!=fn or not fn.lower().endswith(".png"): raise ValueError("visual filename must be a PNG basename")
            if vid in ids: raise ValueError("duplicate visual id: "+vid)
            ids.add(vid)
            if v.get("template") not in {"A_SEQUENCE_SYSTEM","B_COMPARE_CONTRAST","C_EDITORIAL_HUMAN_CONTEXT"}:
                raise ValueError("invalid template for "+vid)
        cover=[]
        for r in runs:
            if not isinstance(r,dict) or str(r.get("visual_id") or "") not in ids: raise ValueError("run references unknown visual")
            a=int(r.get("beat_start",0)); b=int(r.get("beat_end",0))
            if a<1 or b<a: raise ValueError("invalid beat range")
            cover.extend(range(a,b+1))
        if beat_count is not None and sorted(cover)!=list(range(1,int(beat_count)+1)):
            raise ValueError(f"visual runs must cover beats 1..{beat_count} exactly once")
        return True

    def _script_beat_count(self, ep, manifest):
        import re
        d=Path(ep)/"input"/"script"; xs=sorted(d.glob(f"{manifest.get('episode_id')}_SCRIPT_FINAL.txt")) if d.exists() else []
        if not xs: return None
        text=xs[-1].read_text(encoding="utf-8")
        blocks=re.split(r"\n\s*\n+",text.strip()) if text.strip() else []
        count=0
        for block in blocks:
            lines=[x.strip() for x in block.splitlines() if x.strip()]
            lines=[x for x in lines if not re.fullmatch(r"V\d{2,3}",x,re.I)]
            if lines: count+=1
        return count

    def _advance_after_import(self, ep, manifest, stage, completed_packet):
        if stage=="VISUAL_PLAN":
            result=completed_packet.get("result",{})
            if result.get("status")=="FAIL":
                self._set_stage(manifest,stage,"FAILED",current=True); return
            mapping=_find_key(result,"visual_mapping")
            self._validate_mapping(mapping,self._script_beat_count(ep,manifest))
            p=self._mapping_path(ep,manifest); _write(p,mapping)
            self._set_stage(manifest,"VISUAL_PLAN","COMPLETE")
            self._set_stage(manifest,"VISUAL_BUILD","READY",current=True)
            return
        return super()._advance_after_import(ep,manifest,stage,completed_packet)

    def _validate_visual_files(self, ep, manifest):
        from PIL import Image
        mapping,rows=self._expected_visuals(ep,manifest)
        self._validate_mapping(mapping,self._script_beat_count(ep,manifest))
        if not rows: raise RuntimeError("No expected visuals in mapping")
        bad=[]
        for vid,fn,_ in rows:
            p=self._visual_dir(ep)/fn
            if not p.exists(): bad.append(f"{vid}: missing {fn}"); continue
            try:
                with Image.open(p) as im:
                    if tuple(im.size)!=(1920,1080): bad.append(f"{vid}: {im.size[0]}x{im.size[1]}")
            except Exception as e: bad.append(f"{vid}: unreadable {e}")
        if bad: raise RuntimeError("Visual validation failed: "+"; ".join(bad))
        self._set_stage(manifest,"VISUAL_BUILD","COMPLETE")
        self._set_stage(manifest,"VISUAL_QC","READY",current=True)
        self._save_manifest(ep,manifest)
        return {"ok":True,"message":f"Visual import validated · {len(rows)} masters · 1920x1080"}

    def _approve_visuals(self, ep, manifest):
        if self._stage(manifest)!="VISUAL_QC" or self._stage_state(manifest)!="NEEDS_REVIEW":
            raise RuntimeError("Visuals are not awaiting human review")
        manifest.setdefault("visuals",{})["status"]="FINAL_LOCK"
        manifest.setdefault("workstreams",{}).setdefault("visuals",{})["status"]="FINAL_LOCK"
        self._set_stage(manifest,"VISUAL_QC","COMPLETE",decision="APPROVE")
        self._set_stage(manifest,"VOICE","READY",current=True)
        self._save_manifest(ep,manifest)
        return {"ok":True,"message":"Visuals FINAL LOCK · media build ready"}

    def _rework_visuals(self, ep, manifest):
        self._set_stage(manifest,"VISUAL_QC","COMPLETE",decision="REWORK")
        self._set_stage(manifest,"VISUAL_PLAN","READY",current=True)
        self._save_manifest(ep,manifest)
        return {"ok":True,"message":"Visuals returned to Visual Plan"}

    def _latest(self, folder, pattern):
        xs=[p for p in Path(folder).glob(pattern) if p.is_file()] if Path(folder).exists() else []
        return max(xs,key=lambda p:p.stat().st_mtime) if xs else None

    def _approve_preview(self, ep, manifest):
        import hashlib
        if self._stage(manifest)!="PREVIEW_REVIEW" or self._stage_state(manifest)!="NEEDS_REVIEW":
            raise RuntimeError("Preview is not awaiting review")
        eid=manifest.get("episode_id")
        preview=self._latest(Path(ep)/"output"/"preview",f"{eid}_PREVIEW_v*.mp4")
        srt=self._latest(Path(ep)/"work"/"srt",f"{eid}_UPLOAD_v*.srt")
        qc=self._latest(Path(ep)/"output"/"preview",f"{eid}_QC_v*.json")
        if not preview or not srt or not qc: raise RuntimeError("Preview/SRT/QC artifact missing")
        outv=Path(ep)/"output"/"final"/f"{eid}_FINAL.mp4"
        outs=Path(ep)/"output"/"publishing"/f"{eid}_UPLOAD_FINAL.srt"
        outv.parent.mkdir(parents=True,exist_ok=True); outs.parent.mkdir(parents=True,exist_ok=True)
        if outv.exists() or outs.exists(): raise RuntimeError("FINAL output already exists; silent overwrite blocked")
        shutil.copy2(preview,outv); shutil.copy2(srt,outs)
        def sh(p):
            h=hashlib.sha256(); h.update(Path(p).read_bytes()); return h.hexdigest()
        if sh(preview)!=sh(outv): raise RuntimeError("Final video promotion hash mismatch")
        manifest.setdefault("video",{})["status"]="FINAL_LOCK"
        self._set_stage(manifest,"PREVIEW_REVIEW","COMPLETE",decision="APPROVE")
        self._set_stage(manifest,"FINAL","COMPLETE")
        self._set_stage(manifest,"THUMBNAIL","READY",current=True)
        self._save_manifest(ep,manifest)
        return {"ok":True,"message":"Preview promoted to FINAL · Publishing front end ready","final":str(outv),"srt":str(outs)}

    def _rework_preview(self, ep, manifest):
        self._set_stage(manifest,"PREVIEW_REVIEW","COMPLETE",decision="REWORK")
        self._set_stage(manifest,"VOICE","READY",current=True)
        self._save_manifest(ep,manifest)
        return {"ok":True,"message":"Preview returned to media build; valid voice cache may be reused"}

    def inspect(self, ep, manifest):
        ui=super().inspect(ep,manifest)
        stage=self._stage(manifest); state=self._stage_state(manifest,stage)
        ui["adapter_id"]=self.ADAPTER_ID; ui["production_status"]="MEDIA_CANDIDATE"
        if stage=="VISUAL_BUILD":
            ui.update({"buttons":[
                {"action":"open_visual_folder","label":"Open Visual Folder","primary":True},
                {"action":"validate_visuals","label":"Validate Imported Visuals","primary":False},
            ],"task_exists":False,"import_result":False,"message":"Place the final 1920x1080 PNG masters named by the locked visual mapping into input/visuals, then validate."})
        elif stage=="VISUAL_QC" and state=="NEEDS_REVIEW":
            ui["buttons"]=[
                {"action":"approve_visuals","label":"Approve Visuals","primary":True},
                {"action":"rework_visuals","label":"Rework Visuals","primary":False},
            ]
            ui["message"]="Visual QC result is ready for human FINAL LOCK review."
        elif stage in MEDIA_STAGES:
            if stage=="PREVIEW_REVIEW" and state=="NEEDS_REVIEW":
                ui["buttons"]=[
                    {"action":"approve_preview","label":"Approve Preview","primary":True},
                    {"action":"rework_preview","label":"Rework Preview","primary":False},
                ]
                ui["review"]={"type":"PREVIEW","qc":self._preview_qc(ep,manifest)}
                ui["message"]="Actual Kokoro/WAV/SRT/FFmpeg preview is ready for human review."
            else:
                ui["buttons"]=[]
                ui["message"]="Actual media pipeline is ready. Build Preview uses locked script + locked imported visuals."
        return ui

    def job_spec(self, job_name, context):
        if job_name not in {"BUILD_PREVIEW","BUILD_VOICE_ONLY"}: return None
        ep=self._context_ep(context); m=self._context_manifest(context)
        runner=self.root/"factory"/"runners"/"en_bts_production_media_v10.py"
        command=[sys.executable,str(runner),"--root",str(self.root),"--episode",str(ep)]
        if job_name=="BUILD_VOICE_ONLY": command.append("--voice-only")
        return {
            "job_name":job_name,
            "stage":"VOICE" if job_name=="BUILD_VOICE_ONLY" else "RENDER",
            "resource_class":"TTS_SERVICE" if job_name=="BUILD_VOICE_ONLY" else "HEAVY_RENDER",
            "runner":"factory/runners/en_bts_production_media_v10.py",
            "command":command,
            "cwd":str(self.root),
            "progress_path":str(Path(ep)/"work"/"job_status.json"),
            "retry_policy":self.retry_policy("VOICE" if job_name=="BUILD_VOICE_ONLY" else "RENDER",None,context),
            "episode_id":m.get("episode_id"),
        }

    def retry_policy(self, stage, failure, context):
        if stage in MEDIA_STAGES:
            return {"retryable":True,"resume_point":"VOICE","cache_reuse":True,"max_safe_retries":2,"human_intervention":False}
        return super().retry_policy(stage,failure,context)

    def invoke_action(self, action, context, body):
        m=self._context_manifest(context); ep=self._context_ep(context); action=str(action or "")
        if action=="open_visual_folder":
            d=self._visual_dir(ep); d.mkdir(parents=True,exist_ok=True)
            return {"ok":True,"message":"OPEN_TASK_PATH","path":str(d)}
        if action=="validate_visuals": return self._validate_visual_files(ep,m)
        if action=="approve_visuals": return self._approve_visuals(ep,m)
        if action=="rework_visuals": return self._rework_visuals(ep,m)
        if action=="approve_preview": return self._approve_preview(ep,m)
        if action=="rework_preview": return self._rework_preview(ep,m)
        return super().invoke_action(action,context,body)
