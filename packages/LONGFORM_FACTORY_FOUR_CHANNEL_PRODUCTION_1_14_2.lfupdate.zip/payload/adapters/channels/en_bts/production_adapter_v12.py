from __future__ import annotations
from pathlib import Path
from adapters.channels.en_bts.production_adapter_v11 import ENBTSProductionAdapter as ENBTSProductionAdapterV11

class ENBTSProductionAdapter(ENBTSProductionAdapterV11):
    ADAPTER_ID="EN_BTS_PRODUCTION_ADAPTER_v1_2"
    DISPLAY_NAME="Between the Steps — Production"
    def describe(self,context):
        out=super().describe(context); out.update({"adapter_id":self.ADAPTER_ID,"adapter_version":"1.2","production_status":"ACTIVE_PRODUCTION","integration_status":"ACTIVE_PRODUCTION"}); return out
    def inspect(self,ep,m):
        ui=super().inspect(ep,m); ui["adapter_id"]=self.ADAPTER_ID; ui["production_status"]="ACTIVE_PRODUCTION"; stage=self._stage(m); state=self._stage_state(m,stage)
        if stage=="PUBLISHING_QC" and state=="NEEDS_REVIEW": ui["buttons"]=[{"action":"approve_publishing","label":"Approve Publishing","primary":True},{"action":"open_publishing_folder","label":"Open Publishing Folder","primary":False}]
        return ui
    def _publishing_files(self,ep,m):
        eid=m["episode_id"]; pub=Path(ep)/"output/publishing"; return {"final":Path(ep)/"output/final"/f"{eid}_FINAL.mp4","srt":pub/f"{eid}_UPLOAD_FINAL.srt","thumbnail":pub/f"{eid}_THUMBNAIL_FINAL.png","title":pub/f"{eid}_TITLE.txt","description":pub/f"{eid}_DESCRIPTION.txt","tags":pub/f"{eid}_TAGS.txt"}
    def _approve_publishing(self,ep,m):
        from PIL import Image
        files=self._publishing_files(ep,m); missing=[k for k,p in files.items() if not p.exists()]
        if missing: raise RuntimeError("Publishing artifacts missing: "+", ".join(missing))
        with Image.open(files["thumbnail"]) as im:
            if tuple(im.size)!=(1280,720): raise RuntimeError("Thumbnail must be 1280x720")
        if not files["title"].read_text(encoding="utf-8").strip(): raise RuntimeError("Title empty")
        self._set_stage(m,"PUBLISHING_QC","COMPLETE",decision="APPROVE"); self._set_stage(m,"PUBLISHING_REVIEW","COMPLETE",decision="APPROVE"); self._set_stage(m,"UPLOAD_READY","COMPLETE",current=True); m.setdefault("lifecycle",{})["state"]="COMPLETE"; m.setdefault("publishing",{})["status"]="FINAL_LOCK"; self._save_manifest(ep,m); return {"ok":True,"message":"Publishing Package FINAL LOCK · UPLOAD_READY"}
    def invoke_action(self,action,context,body):
        m=self._context_manifest(context); ep=self._context_ep(context); action=str(action or "")
        if action=="open_publishing_folder": d=Path(ep)/"output/publishing"; d.mkdir(parents=True,exist_ok=True); return {"ok":True,"message":"OPEN_TASK_PATH","path":str(d)}
        if action=="approve_publishing": return self._approve_publishing(ep,m)
        return super().invoke_action(action,context,body)
