from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import json

from adapters.channels.base_capability_adapter import DeclarativeCapabilityAdapter

STAGES = [
    "DISCOVERY","GREENLIGHT","RESEARCH","FACT_LOCK","SCRIPT","SCRIPT_QC",
    "VISUAL_PLAN","VISUAL_BUILD","VISUAL_QC","VOICE","TIMING","SUBTITLES",
    "EDIT_PLAN","RENDER","AUTO_QC","PREVIEW_REVIEW","FINAL",
    "THUMBNAIL","TITLE","DESCRIPTION","TAGS",
    "PUBLISHING_QC","PUBLISHING_REVIEW","UPLOAD_READY"
]

REASONING_STAGES = {
    "DISCOVERY","RESEARCH","FACT_LOCK","SCRIPT","SCRIPT_QC","VISUAL_PLAN",
    "VISUAL_QC","THUMBNAIL","TITLE","DESCRIPTION","TAGS","PUBLISHING_QC"
}

TASK_INSTRUCTIONS = {
    "DISCOVERY": (
        "Run EN_BTS revenue-first discovery. Return evidence-backed topic candidates. "
        "For each candidate preserve demand evidence, duplicate status, feasibility, "
        "working title angle, thumbnail concept and channel/revenue fit. "
        "Use decisions[] objects with candidate_id and premise when possible."
    ),
    "RESEARCH": (
        "Create an EN_BTS research pack for the greenlit premise. Separate sources, "
        "verified findings, uncertainty, company-reported claims and contested claims."
    ),
    "FACT_LOCK": (
        "Create the EN_BTS Fact Lock. For every important claim use KEEP, DROP or NEED_REVIEW. "
        "Do not invent private/non-public system mechanics."
    ),
    "SCRIPT": (
        "Draft the EN_BTS narration script from the locked factual scope. "
        "Keep information-first pacing and do not strengthen qualifiers. "
        "Place the full proposed script in a findings[] or decisions[] object under script_text."
    ),
    "SCRIPT_QC": (
        "QC the EN_BTS script for factual scope, structure, clarity, revenue premise alignment, "
        "and production readiness. Return the corrected complete script under script_text."
    ),
    "VISUAL_PLAN": (
        "Plan EN_BTS visuals from the FINAL script using BTS_CANONICAL_VISUAL_TEMPLATE_v1_1. "
        "Route semantic blocks to A_SEQUENCE_SYSTEM, B_COMPARE_CONTRAST or C_EDITORIAL_HUMAN_CONTEXT. "
        "Prefer reuse, containerless layouts and deterministic finalization. No arrows/connectors."
    ),
    "VISUAL_QC": (
        "QC EN_BTS visual masters for script alignment, factual scope, template-family correctness, "
        "containerless compliance, no arrows/connectors, subtitle-safe placement, hierarchy, "
        "1920x1080 output and no unauthorized brand UI/logo."
    ),
    "THUMBNAIL": (
        "Create the final EN_BTS thumbnail decision from the completed video. "
        "Treat the earlier packaging concept only as a hypothesis."
    ),
    "TITLE": "Create the final EN_BTS upload title from the completed video and locked factual scope.",
    "DESCRIPTION": "Create the final EN_BTS upload description including required factual/source context.",
    "TAGS": "Create concise EN_BTS upload tags/keywords. Avoid stuffing.",
    "PUBLISHING_QC": (
        "QC the complete EN_BTS publishing package: thumbnail, title, description, tags, final upload SRT "
        "and required source/disclosure fields."
    ),
}

def _now():
    return datetime.now(timezone.utc).isoformat()

def _read(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {} if default is None else default

def _write(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)

def _find_key(obj, key):
    if isinstance(obj, dict):
        if key in obj:
            return obj[key]
        for value in obj.values():
            found = _find_key(value, key)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = _find_key(value, key)
            if found is not None:
                return found
    return None

class ENBTSProductionAdapter(DeclarativeCapabilityAdapter):
    ADAPTER_ID = "EN_BTS_PRODUCTION_ADAPTER_v1_0"
    CHANNEL_ID = "EN_BTS"
    PROFILE_ID = "EN_TECH_v1"
    DISPLAY_NAME = "Between the Steps — Production"
    REQUIRED_RULES = [
        "BTS_CANONICAL_VISUAL_TEMPLATE_v1_1",
        "EN_BTS_PRODUCTION_ADAPTER_SPEC_v1_0",
    ]
    CAPABILITIES = {
        "reasoning": {
            "provider": "manual_handoff",
            "provider_neutral": True,
            "revenue_first": True,
        },
        "voice": {
            "provider": "KOKORO",
            "mode": "SINGLE_DEFAULT",
            "default_voice": "af_heart",
            "default_speed": 0.96,
            "sample_rate": 24000,
            "timeline_authority": "ACTUAL_GENERATED_WAV",
            "automatic_fallback": False,
        },
        "subtitles": {
            "mode": "EXTERNAL_SRT",
            "timing_authority": "ACTUAL_NARRATION_WAV",
            "burn_in_default": False,
        },
        "visual": {
            "canonical": "BTS_CANONICAL_VISUAL_TEMPLATE_v1_1",
            "routing": ["A_SEQUENCE_SYSTEM","B_COMPARE_CONTRAST","C_EDITORIAL_HUMAN_CONTEXT"],
            "containerless_default": True,
            "arrows_default": False,
            "connectors_default": False,
            "subtitle_safe_y": [820,1080],
            "image_generation_binding": "PROVIDER_NEUTRAL",
            "generated_image_role": "SOURCE_RENDER_ONLY",
            "deterministic_finalizer": True,
            "higgsfield_default": False,
        },
        "publishing": {
            "package_required": True,
            "front_end_gate": "REVENUE_FIRST",
        },
    }

    def describe(self, context):
        out = super().describe(context)
        out.update({
            "adapter_version": "1.0",
            "production_status": "CANDIDATE",
            "integration_status": "PRODUCTION_CANDIDATE",
            "required_rules": list(self.REQUIRED_RULES),
            "capabilities": self.CAPABILITIES,
        })
        return out

    def _context_manifest(self, context):
        m = (context or {}).get("manifest")
        if not isinstance(m, dict):
            raise ValueError("manifest missing from adapter context")
        return m

    def _context_ep(self, context):
        for key in ("episode_path","episode_dir","ep"):
            value = (context or {}).get(key)
            if value:
                return Path(value)
        m = self._context_manifest(context)
        eid = m.get("episode_id")
        if not eid:
            raise ValueError("episode_id missing")
        return self.root / "projects" / self.CHANNEL_ID / "episodes" / eid

    def _stage(self, manifest):
        return manifest.get("lifecycle",{}).get("current_stage","DISCOVERY")

    def _stage_state(self, manifest, stage=None):
        stage = stage or self._stage(manifest)
        return manifest.get("lifecycle",{}).get("stages",{}).get(stage,{}).get("runtime_state","NOT_STARTED")

    def _reason_dir(self, ep):
        return Path(ep) / "work" / "reasoning"

    def _task_copy(self, ep, stage):
        return self._reason_dir(ep) / f"{stage}_task.json"

    def _result_copy(self, ep, stage):
        return self._reason_dir(ep) / f"{stage}_result.json"

    def _save_manifest(self, ep, manifest):
        _write(Path(ep) / "episode_manifest.json", manifest)

    def _set_stage(self, manifest, stage, state, *, current=False, decision=None):
        lc = manifest.setdefault("lifecycle", {})
        stages = lc.setdefault("stages", {})
        item = stages.setdefault(stage, {})
        item["runtime_state"] = state
        item["updated_at"] = _now()
        if decision is not None:
            item["review_decision"] = decision
        if current:
            lc["current_stage"] = stage

    def _task_context(self, ep, manifest, stage):
        return {
            "adapter_id": self.ADAPTER_ID,
            "adapter_spec": "EN_BTS_PRODUCTION_ADAPTER_SPEC_v1_0",
            "visual_canonical": "BTS_CANONICAL_VISUAL_TEMPLATE_v1_1",
            "episode_id": manifest.get("episode_id"),
            "stage": stage,
            "profile": self.PROFILE_ID,
            "revenue_first_order": [
                "Market Evidence","Premise","Title/Thumbnail Concept",
                "Comparable","Revenue Gate"
            ],
            "episode_path": str(Path(ep)),
        }

    def preflight(self, stage, context):
        base = super().preflight(stage, context)
        m = self._context_manifest(context)
        checks = list(base.get("checks", []))
        aid = m.get("authority",{}).get("channel_adapter")
        checks.append({
            "name":"Pinned adapter",
            "pass": aid == self.ADAPTER_ID,
            "detail": str(aid),
        })
        media = self._media_binding()
        if stage in {"VOICE","TIMING","SUBTITLES","EDIT_PLAN","RENDER","AUTO_QC","PREVIEW_REVIEW","FINAL"}:
            checks.append({
                "name":"EN_BTS representative media smoke",
                "pass": media == "ACTIVE_MEDIA_SMOKE",
                "detail": media,
            })
            script_status = (
                m.get("script",{}).get("status")
                or m.get("workstreams",{}).get("script",{}).get("status")
                or ""
            )
            checks.append({
                "name":"Script FINAL LOCK",
                "pass": str(script_status).upper() in {"FINAL_LOCK","LOCK"},
                "detail": script_status or "missing",
            })
        return {
            "pass": all(bool(x.get("pass")) for x in checks),
            "checks": checks,
            "resource_class": self._resource_class(stage),
        }

    def _resource_class(self, stage):
        if stage in REASONING_STAGES:
            return "REASONING"
        if stage == "VOICE":
            return "TTS_SERVICE"
        if stage == "VISUAL_BUILD":
            return "IMAGE_GENERATION"
        if stage in {"RENDER","FINAL"}:
            return "HEAVY_RENDER"
        if stage == "AUTO_QC":
            return "QC"
        if stage in {"PUBLISHING_REVIEW","UPLOAD_READY"}:
            return "PUBLISHING"
        return "LIGHT"

    def next_action(self, context):
        m = self._context_manifest(context)
        ep = self._context_ep(context)
        ui = self.inspect(ep, m)
        buttons = ui.get("buttons") or []
        primary = next((b for b in buttons if b.get("primary")), None) or (buttons[0] if buttons else None)
        if primary:
            return {
                "action": primary.get("action"),
                "label": primary.get("label","Continue"),
                "stage": ui.get("stage"),
                "reason": ui.get("message",""),
            }
        return {
            "action":"INSPECT",
            "label":"Inspect",
            "stage":ui.get("stage"),
            "reason":ui.get("message",""),
        }

    def execute(self, stage, context, reporter=None):
        if stage in REASONING_STAGES:
            return {
                "stage":stage,
                "state":"BLOCKED",
                "artifacts":[],
                "metrics":{},
                "warnings":["Use manual_handoff through invoke_action(create_task/import_result)."],
                "next_recommended_action":"CREATE_REASONING_TASK",
            }
        return {
            "stage":stage,
            "state":"BLOCKED",
            "artifacts":[],
            "metrics":{},
            "warnings":["Production media runner is not activated in candidate phase."],
            "next_recommended_action":"COMPLETE_CANDIDATE_QA",
        }

    def validate(self, stage, result, context):
        ok = isinstance(result, dict) and result.get("stage") == stage and result.get("state") in {"COMPLETE","NEEDS_REVIEW","BLOCKED","FAILED"}
        return {"pass":ok,"checks":[{"name":"Result envelope","pass":ok,"detail":stage}]}

    def retry_policy(self, stage, failure, context):
        if stage in REASONING_STAGES:
            return {
                "retryable":True,
                "resume_point":stage,
                "cache_reuse":True,
                "max_safe_retries":2,
                "human_intervention":True,
            }
        return {
            "retryable":False,
            "resume_point":None,
            "cache_reuse":False,
            "max_safe_retries":0,
            "human_intervention":True,
        }

    def artifacts(self, stage, context):
        return []

    def job_spec(self, job_name, context):
        return None

    def _load_task(self, ep, stage):
        return _read(self._task_copy(ep, stage), {})

    def _load_result(self, ep, stage):
        return _read(self._result_copy(ep, stage), {})

    def inspect(self, ep, manifest):
        ep = Path(ep)
        stage = self._stage(manifest)
        state = self._stage_state(manifest, stage)
        buttons = []
        task = self._load_task(ep, stage)
        result = self._load_result(ep, stage)
        import_result = False
        candidates = []
        review = None
        message = "EN_BTS production candidate."

        if stage in REASONING_STAGES:
            if not task:
                buttons.append({"action":"create_task","label":"Prepare Task","primary":True})
                message = f"{stage.replace('_',' ').title()} task is ready to prepare."
            elif task.get("status") == "AWAITING_MANUAL_RESULT" and not result:
                buttons.append({"action":"copy_prompt","label":"Copy Task Prompt","primary":True})
                import_result = True
                message = "Manual reasoning result is required."
            elif stage == "SCRIPT_QC" and state == "NEEDS_REVIEW":
                script_text = _find_key(result.get("result", result), "script_text") or ""
                review = {
                    "type":"SCRIPT",
                    "qc_status":result.get("result",result).get("status",""),
                    "issues":result.get("result",result).get("findings",[]),
                    "script_text":script_text,
                }
                buttons += [
                    {"action":"approve_script","label":"Approve Script","primary":True},
                    {"action":"rework_script","label":"Rework Script","primary":False},
                ]
            elif stage == "VISUAL_QC" and state == "NEEDS_REVIEW":
                review = {"type":"VISUAL","visual_count":0,"run_count":0,"static_ratio":None,"reveal_checks":[],"missing":[]}
                buttons += [
                    {"action":"approve_visuals","label":"Approve Visuals","primary":True},
                    {"action":"rework_visuals","label":"Rework Visuals","primary":False},
                ]
            elif stage == "PUBLISHING_QC" and state == "NEEDS_REVIEW":
                review = {"type":"PUBLISHING","title":"","description":"","tags":"","qc":result.get("result",result)}
                buttons += [
                    {"action":"approve_publishing","label":"Approve Publishing","primary":True},
                    {"action":"rework_publishing","label":"Rework Publishing","primary":False},
                ]

        if stage == "GREENLIGHT":
            disc = self._load_result(ep, "DISCOVERY")
            r = disc.get("result", disc)
            raw = r.get("decisions",[]) if isinstance(r,dict) else []
            candidates = [x for x in raw if isinstance(x,dict) and x.get("candidate_id")]
            message = "Review revenue-first discovery candidates."

        if stage == "VISUAL_BUILD":
            message = "Visual production/import runner is pending the next promotion gate."

        if stage in {"VOICE","TIMING","SUBTITLES","EDIT_PLAN","RENDER","AUTO_QC","PREVIEW_REVIEW","FINAL"}:
            message = "Production media runner is pending the next promotion gate."

        return {
            "active":True,
            "adapter_id":self.ADAPTER_ID,
            "production_status":"CANDIDATE",
            "stage":stage,
            "state":state,
            "buttons":buttons,
            "task_exists":bool(task),
            "import_result":import_result,
            "candidates":candidates,
            "review":review,
            "message":message,
        }

    def _create_task(self, ep, manifest):
        stage = self._stage(manifest)
        if stage not in REASONING_STAGES:
            raise RuntimeError(f"{stage} is not a reasoning stage")
        existing = self._load_task(ep, stage)
        if existing and existing.get("status") == "AWAITING_MANUAL_RESULT":
            return {"ok":True,"message":"Existing task reused","task_id":existing.get("task_id")}
        import reasoning_provider_bridge as reasoning
        task = {
            "task_type":f"EN_BTS_{stage}",
            "channel_id":self.CHANNEL_ID,
            "episode_id":manifest.get("episode_id"),
            "instruction":TASK_INSTRUCTIONS.get(stage, f"Complete EN_BTS {stage}."),
            "context":self._task_context(ep, manifest, stage),
        }
        packet = reasoning.execute_task(self.root, task=task)
        _write(self._task_copy(ep, stage), packet)
        self._set_stage(manifest, stage, "BLOCKED", current=True)
        self._save_manifest(ep, manifest)
        return {"ok":True,"message":"Reasoning task prepared","task_id":packet.get("task_id")}

    def _get_prompt(self, ep, manifest):
        stage = self._stage(manifest)
        task = self._load_task(ep, stage)
        if not task:
            raise RuntimeError("Prepare the task first")
        return {"ok":True,"message":"Prompt ready","prompt_text":task.get("manual_prompt","")}

    def _advance_after_import(self, ep, manifest, stage, completed_packet):
        result = completed_packet.get("result", {})
        if result.get("status") == "FAIL":
            self._set_stage(manifest, stage, "FAILED", current=True)
            return
        if stage == "DISCOVERY":
            self._set_stage(manifest, "DISCOVERY", "COMPLETE")
            self._set_stage(manifest, "GREENLIGHT", "NEEDS_REVIEW", current=True)
        elif stage == "RESEARCH":
            self._set_stage(manifest, "RESEARCH", "COMPLETE")
            self._set_stage(manifest, "FACT_LOCK", "READY", current=True)
        elif stage == "FACT_LOCK":
            blocking = any(
                isinstance(x,dict) and str(x.get("decision","")).upper() == "NEED_REVIEW"
                for x in (result.get("decisions") or [])
            )
            if blocking:
                self._set_stage(manifest, "FACT_LOCK", "BLOCKED", current=True)
            else:
                self._set_stage(manifest, "FACT_LOCK", "COMPLETE")
                self._set_stage(manifest, "SCRIPT", "READY", current=True)
        elif stage == "SCRIPT":
            self._set_stage(manifest, "SCRIPT", "COMPLETE")
            self._set_stage(manifest, "SCRIPT_QC", "READY", current=True)
        elif stage == "SCRIPT_QC":
            self._set_stage(manifest, "SCRIPT_QC", "NEEDS_REVIEW", current=True)
        elif stage == "VISUAL_PLAN":
            self._set_stage(manifest, "VISUAL_PLAN", "COMPLETE")
            self._set_stage(manifest, "VISUAL_BUILD", "READY", current=True)
        elif stage == "VISUAL_QC":
            self._set_stage(manifest, "VISUAL_QC", "NEEDS_REVIEW", current=True)
        elif stage == "THUMBNAIL":
            self._set_stage(manifest, "THUMBNAIL", "COMPLETE")
            self._set_stage(manifest, "TITLE", "READY", current=True)
        elif stage == "TITLE":
            self._set_stage(manifest, "TITLE", "COMPLETE")
            self._set_stage(manifest, "DESCRIPTION", "READY", current=True)
        elif stage == "DESCRIPTION":
            self._set_stage(manifest, "DESCRIPTION", "COMPLETE")
            self._set_stage(manifest, "TAGS", "READY", current=True)
        elif stage == "TAGS":
            self._set_stage(manifest, "TAGS", "COMPLETE")
            self._set_stage(manifest, "PUBLISHING_QC", "READY", current=True)
        elif stage == "PUBLISHING_QC":
            self._set_stage(manifest, "PUBLISHING_QC", "NEEDS_REVIEW", current=True)

    def _import_result(self, ep, manifest, body):
        stage = self._stage(manifest)
        task = self._load_task(ep, stage)
        if not task:
            raise RuntimeError("No task prepared for current stage")
        raw = body.get("result")
        if isinstance(raw, str):
            result = json.loads(raw)
        elif isinstance(raw, dict):
            result = raw
        else:
            raise ValueError("result JSON required")
        import reasoning_provider_bridge as reasoning
        completed = reasoning.execute_task(self.root, result=result, task_id=task.get("task_id"))
        _write(self._result_copy(ep, stage), completed)
        self._advance_after_import(ep, manifest, stage, completed)
        self._save_manifest(ep, manifest)
        return {"ok":True,"message":f"{stage} result imported"}

    def _greenlight(self, ep, manifest, body):
        if self._stage(manifest) != "GREENLIGHT":
            raise RuntimeError("Not at GREENLIGHT")
        decision = str(body.get("decision","")).upper()
        if decision not in {"GREENLIGHT","REWORK","DROP"}:
            raise ValueError("decision must be GREENLIGHT, REWORK or DROP")
        if decision == "GREENLIGHT":
            self._set_stage(manifest, "GREENLIGHT", "COMPLETE", decision=decision)
            self._set_stage(manifest, "RESEARCH", "READY", current=True)
        elif decision == "REWORK":
            self._set_stage(manifest, "GREENLIGHT", "COMPLETE", decision=decision)
            self._set_stage(manifest, "DISCOVERY", "READY", current=True)
        else:
            self._set_stage(manifest, "GREENLIGHT", "DROPPED", decision=decision)
            manifest.setdefault("lifecycle",{})["state"] = "DROPPED"
        self._save_manifest(ep, manifest)
        return {"ok":True,"message":f"Greenlight decision: {decision}"}

    def _approve_script(self, ep, manifest):
        if self._stage(manifest) != "SCRIPT_QC" or self._stage_state(manifest) != "NEEDS_REVIEW":
            raise RuntimeError("Script is not awaiting review")
        result = self._load_result(ep, "SCRIPT_QC")
        script_text = _find_key(result.get("result", result), "script_text")
        if not isinstance(script_text, str) or not script_text.strip():
            raise RuntimeError("SCRIPT_QC result does not contain script_text")
        eid = manifest.get("episode_id")
        out = Path(ep) / "input" / "script" / f"{eid}_SCRIPT_FINAL.txt"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(script_text.rstrip() + "\n", encoding="utf-8")
        manifest.setdefault("script",{})["status"] = "FINAL_LOCK"
        manifest.setdefault("workstreams",{}).setdefault("script",{})["status"] = "FINAL_LOCK"
        self._set_stage(manifest, "SCRIPT_QC", "COMPLETE", decision="APPROVE")
        self._set_stage(manifest, "VISUAL_PLAN", "READY", current=True)
        self._save_manifest(ep, manifest)
        return {"ok":True,"message":"Script FINAL LOCK created","path":str(out)}

    def _rework_script(self, ep, manifest):
        self._set_stage(manifest, "SCRIPT_QC", "COMPLETE", decision="REWORK")
        self._set_stage(manifest, "SCRIPT", "READY", current=True)
        self._save_manifest(ep, manifest)
        return {"ok":True,"message":"Script returned to rework"}

    def invoke_action(self, action, context, body):
        m = self._context_manifest(context)
        ep = self._context_ep(context)
        action = str(action or "")
        if action == "create_task":
            return self._create_task(ep, m)
        if action == "get_prompt":
            return self._get_prompt(ep, m)
        if action == "import_result":
            return self._import_result(ep, m, body or {})
        if action == "greenlight":
            return self._greenlight(ep, m, body or {})
        if action == "approve_script":
            return self._approve_script(ep, m)
        if action == "rework_script":
            return self._rework_script(ep, m)
        if action in {"approve_visuals","rework_visuals","approve_publishing","rework_publishing"}:
            raise RuntimeError(f"{action} is reserved for the next production-runner promotion gate")
        raise RuntimeError(f"Unknown EN_BTS production action: {action}")
