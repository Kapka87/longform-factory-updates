from __future__ import annotations
from pathlib import Path
import importlib.util, json, re
from adapters.channels.production_adapter_common_v10 import ProductionLifecycleAdapter,_find_key,_write

class ENStoryProductionAdapter(ProductionLifecycleAdapter):
    ADAPTER_ID="EN_STORY_PRODUCTION_ADAPTER_v1_0"; CHANNEL_ID="EN_STORY"; PROFILE_ID="EN_DRAMA_v1"; DISPLAY_NAME="English Story Longform — Production"; ADAPTER_VERSION="1.0"; RUNNER_REL="factory/runners/en_story_production_media_v10.py"; SCRIPT_SCHEMA="EN_STORY_PRODUCTION_SCRIPT_v1"; MAPPING_SCHEMA="EN_STORY_VISUAL_MAPPING_v1"
    REQUIRED_RULES=["STORY_LONGFORM_EDITING_CANONICAL_RULES_v1_0"]
    CAPABILITIES={"reasoning":{"provider":"manual_handoff","provider_neutral":True,"revenue_first":True},"voice":{"provider":"KOKORO","mode":"TWO_VOICE_DIALOGUE","casting":"DECLARATIVE_PER_EPISODE","canonical_voices":{"HEART":"af_heart","LIAM":"am_liam"},"timeline_authority":"ACTUAL_GENERATED_WAV"},"editing":{"mode":"DIALOGUE_STORY_BEAT","static_first":True,"speaker_focus":True,"speaker_focus_fixed_frame":True,"motion_scope":"VISUAL_RUN"},"subtitles":{"mode":"EXTERNAL_SRT","timing_authority":"ACTUAL_NARRATION_WAV"},"publishing":{"package_required":True},"visual":{"mode":"STORY_STILLS","speaker_focus_supported":True,"image_generation_binding":"PROVIDER_NEUTRAL"}}
    TASK_INSTRUCTIONS={
      "DISCOVERY":"Run revenue-first discovery for EN_STORY two-voice drama. Return evidence-backed premise candidates with candidate_id, premise, title/thumbnail hook, comparable evidence, channel fit and production feasibility in decisions[].",
      "RESEARCH":"Research the greenlit EN_STORY premise. Separate verified facts, uncertain details, story assumptions and source notes.",
      "FACT_LOCK":"Create the EN_STORY Fact Lock. Use KEEP, DROP or NEED_REVIEW for claims that constrain the script.",
      "SCRIPT":"Draft a complete two-voice EN_STORY script for HEART and LIAM. Preserve story-beat editing. Return script_json inside decisions[] with schema EN_STORY_PRODUCTION_SCRIPT_v1, casting, and lines[{id,speaker,text,subtitle_text,pause_after}]. Use voices af_heart and am_liam unless an episode-specific approved override is required.",
      "SCRIPT_QC":"QC and correct the complete EN_STORY script. Return the full corrected script_json using schema EN_STORY_PRODUCTION_SCRIPT_v1.",
      "VISUAL_PLAN":"Plan story visuals from the FINAL script. Return visual_mapping in decisions[] with schema EN_STORY_VISUAL_MAPPING_v1, visuals[{id,filename,role}], runs[{visual_id,line_start,line_end,motion:STATIC|SLOW_PUSH,speaker_focus:boolean,speaker_regions?}]. Edit by story beat, not dialogue line. Speaker Focus requires STATIC fixed underlying frame. Every line must be covered exactly once.",
      "VISUAL_QC":"QC all EN_STORY visual masters and mapping for story alignment, continuity, 1920x1080, story-beat run structure, static-first motion, and Speaker Focus fixed-frame rule.",
      "THUMBNAIL":"Define the final thumbnail for the completed EN_STORY video.","TITLE":"Create the final upload title.","DESCRIPTION":"Create the final description.","TAGS":"Create concise upload tags.","PUBLISHING_QC":"QC final video, thumbnail, title, description, tags and final upload SRT."
    }
    def _materialize_script(self,ep,m,result):
        data=_find_key(result,"script_json")
        if not isinstance(data,dict) or data.get("schema")!=self.SCRIPT_SCHEMA:raise RuntimeError("SCRIPT_QC result requires script_json with EN_STORY_PRODUCTION_SCRIPT_v1")
        lines=data.get("lines") or []; casting=data.get("casting") or {"HEART":{"voice":"af_heart"},"LIAM":{"voice":"am_liam"}}
        if not lines:raise RuntimeError("script_json.lines required")
        for i,row in enumerate(lines,1):
            if row.get("speaker") not in casting or not str(row.get("text") or "").strip():raise RuntimeError(f"Invalid story line {i}")
            row.setdefault("id",f"L{i:03d}"); row.setdefault("subtitle_text",row.get("text")); row.setdefault("pause_after",0.35)
        data["casting"]=casting; eid=m["episode_id"]; p=Path(ep)/"input/script"/f"{eid}_SCRIPT_FINAL.json"; _write(p,data); (Path(ep)/"input/script"/f"{eid}_SCRIPT_FINAL.txt").write_text("\n".join(f"{x['speaker']}: {x['text']}" for x in lines)+"\n",encoding="utf-8"); return p
    def _unit_count(self,ep,m):
        p=Path(ep)/"input/script"/f"{m['episode_id']}_SCRIPT_FINAL.json"; import json; return len(json.loads(p.read_text(encoding="utf-8")).get("lines") or []) if p.exists() else None
    def _validate_mapping(self,mapping,unit_count=None):
        if not isinstance(mapping,dict) or mapping.get("schema")!=self.MAPPING_SCHEMA:raise ValueError("visual_mapping schema invalid")
        ids={str(v.get("id")) for v in (mapping.get("visuals") or []) if isinstance(v,dict) and v.get("id") and v.get("filename")}; cover=[]
        if not ids:raise ValueError("visuals required")
        for r in mapping.get("runs") or []:
            if str(r.get("visual_id")) not in ids:raise ValueError("unknown visual")
            a=int(r.get("line_start",0)); b=int(r.get("line_end",0));
            if a<1 or b<a:raise ValueError("invalid line range")
            if r.get("speaker_focus") and str(r.get("motion") or "STATIC").upper()!="STATIC":raise ValueError("Speaker Focus requires STATIC")
            cover.extend(range(a,b+1))
        if unit_count is not None and sorted(cover)!=list(range(1,unit_count+1)):raise ValueError("runs must cover every line exactly once")
        return True
    def _media_extra_checks(self,ep,m): return [{"name":"Kokoro","pass":importlib.util.find_spec("kokoro") is not None,"detail":"available" if importlib.util.find_spec("kokoro") else "missing"}]
