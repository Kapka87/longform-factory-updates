# Longform Factory v1.14.0 — Four-Channel Production Integration

- EN_STORY production adapter + Kokoro two-voice story runner + fixed-frame Speaker Focus
- EN_BTS production v1.2 with publishing approval through UPLOAD_READY
- JP_BTS production adapter + dynamic VOICEVOX speaker/style mapping
- JP_STORY remains the active media reference
- Adapter Registry v2.0
- Four-channel isolated production QA
- Existing Episode adapter pins are never auto-migrated
- Image generation remains provider-neutral


R3: Fixes bootstrap startup by resolving the QA module path explicitly and injecting Production QA routes at do_GET/do_POST boundaries without depending on the removed local-upload route.


1.14.1 hotfix: Production adapters and media runners now resolve ffmpeg/ffprobe from PATH plus standard macOS Homebrew paths (/opt/homebrew/bin, /usr/local/bin, /opt/local/bin).


1.14.2 hotfix: EN_STORY, EN_BTS and JP_BTS production media runners now resolve ffmpeg/ffprobe using the shared Desktop-safe resolver instead of PATH-only shutil.which().
