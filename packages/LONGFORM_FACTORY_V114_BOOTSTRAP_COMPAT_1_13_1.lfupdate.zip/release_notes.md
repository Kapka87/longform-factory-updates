# Longform Factory v1.13.1 — v1.14 Bootstrap Compatibility Bridge

Adds only the import shim required by the v1.14 bootstrap. Existing episodes, adapters, assets, and the current server remain unchanged.
