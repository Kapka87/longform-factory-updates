from adapters.channels.base_capability_adapter import DeclarativeCapabilityAdapter

class ENBTSReferenceAdapter(DeclarativeCapabilityAdapter):
    ADAPTER_ID='EN_BTS_REFERENCE_ADAPTER_v1_0'
    CHANNEL_ID='EN_BTS'
    PROFILE_ID='EN_TECH_v1'
    DISPLAY_NAME='Between the Steps'
    REQUIRED_RULES=['BTS_CANONICAL_VISUAL_TEMPLATE_v1_1']
    CAPABILITIES={'voice': {'provider': 'KOKORO', 'mode': 'SINGLE_DEFAULT', 'default_voice': 'af_heart', 'timeline_authority': 'ACTUAL_GENERATED_WAV'}, 'editing': {'mode': 'INFORMATION_FIRST', 'visual_runs': 'STRUCTURED_SHORTER'}, 'subtitles': {'mode': 'EXTERNAL_SRT', 'timing_authority': 'ACTUAL_NARRATION_WAV'}, 'publishing': {'package_required': True, 'front_end_gate': 'REVENUE_FIRST'}, 'visual': {'canonical': 'BTS_CANONICAL_VISUAL_TEMPLATE_v1_1', 'containerless_default': True, 'arrows_default': False, 'subtitle_safe_y': [820, 1080]}}
