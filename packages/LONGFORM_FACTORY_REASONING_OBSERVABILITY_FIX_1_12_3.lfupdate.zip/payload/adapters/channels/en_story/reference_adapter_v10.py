from adapters.channels.base_capability_adapter import DeclarativeCapabilityAdapter

class ENStoryReferenceAdapter(DeclarativeCapabilityAdapter):
    ADAPTER_ID='EN_STORY_REFERENCE_ADAPTER_v1_0'
    CHANNEL_ID='EN_STORY'
    PROFILE_ID='EN_DRAMA_v1'
    DISPLAY_NAME='English Story Longform'
    REQUIRED_RULES=['STORY_LONGFORM_EDITING_CANONICAL_RULES_v1_0']
    CAPABILITIES={'voice': {'provider': 'KOKORO', 'mode': 'TWO_VOICE_DIALOGUE', 'casting': 'DECLARATIVE_PER_EPISODE', 'smoke_fixture_voices': ['af_heart', 'am_liam'], 'timeline_authority': 'ACTUAL_GENERATED_WAV'}, 'editing': {'mode': 'DIALOGUE_STORY_BEAT', 'static_first': True, 'speaker_focus': True, 'motion_scope': 'VISUAL_RUN'}, 'subtitles': {'mode': 'EXTERNAL_SRT', 'timing_authority': 'ACTUAL_NARRATION_WAV'}, 'publishing': {'package_required': True}, 'visual': {'mode': 'STORY_STILLS', 'speaker_focus_supported': True}}
