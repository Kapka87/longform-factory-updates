from adapters.channels.base_capability_adapter import DeclarativeCapabilityAdapter

class JPBTSReferenceAdapter(DeclarativeCapabilityAdapter):
    ADAPTER_ID='JP_BTS_REFERENCE_ADAPTER_v1_0'
    CHANNEL_ID='JP_BTS'
    PROFILE_ID='JP_TECH_v1'
    DISPLAY_NAME='Japanese Between the Steps'
    REQUIRED_RULES=['LONGFORM_FACTORY_JP_VOICE_CASTING_POLICY_v1_0']
    CAPABILITIES={'voice': {'provider': 'VOICEVOX', 'mode': 'MULTI_VOICE', 'allowed_pairings': ['male/female', 'male/male', 'female/female'], 'style_resolution': 'DYNAMIC_BY_SPEAKER_AND_STYLE_NAME', 'timeline_authority': 'ACTUAL_GENERATED_WAV'}, 'editing': {'mode': 'INFORMATION_FIRST', 'role_mapping': 'DETERMINISTIC_WITHIN_EPISODE'}, 'subtitles': {'mode': 'EXTERNAL_SRT', 'language': 'ja', 'timing_authority': 'ACTUAL_GENERATED_WAV'}, 'publishing': {'package_required': True}, 'visual': {'mode': 'STRUCTURED_TECH', 'subtitle_safe_required': True}}
