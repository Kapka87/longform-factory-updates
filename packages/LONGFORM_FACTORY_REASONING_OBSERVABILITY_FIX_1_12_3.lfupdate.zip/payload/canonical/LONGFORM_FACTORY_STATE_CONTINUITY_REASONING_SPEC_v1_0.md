# Longform Factory State / Continuity / Reasoning Spec v1.0

Status: ACTIVE CORE GATE

Continuity authority:
- Chat memory is convenience only, never production authority.
- factory/handoff/registry.json points to channel handoff state.
- projects/<CHANNEL>/handoff/CHANNEL_STATE.json and CHANNEL_HANDOFF.md are the stable channel resume surface.
- Episode handoff files are generated only for Factory-managed episode manifests with schema >=1.2. Legacy episodes are not auto-migrated or modified.

Required handoff fields:
AUTHORITY, CURRENT_STAGE, LOCKED_ASSETS, ACTIVE_RULES, OPEN_DECISIONS, KNOWN_FAILURES, NEXT_ACTION, DO_NOT_REOPEN.

Reasoning provider contract:
describe / available / execute_task / result_schema / supports_web.

Core v1 default provider:
manual_handoff. It requires no API key and makes no network call. The Factory prepares a structured task packet; a human can run it in ChatGPT or another reasoning system and paste a schema-valid JSON result back.

Direct API providers may be added later without changing the provider contract.
