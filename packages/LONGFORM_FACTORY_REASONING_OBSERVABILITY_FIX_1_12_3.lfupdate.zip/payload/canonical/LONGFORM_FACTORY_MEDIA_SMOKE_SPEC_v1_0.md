# Longform Factory Representative Media Smoke Spec v1.0

Status: ACTIVE CORE GATE

Scope:
- EN_STORY, EN_BTS, JP_BTS representative media integration.
- Never migrates or modifies existing episode manifests or LOCK/FINAL assets.
- All generated fixtures live under factory/_qa/cross_channel_media/.
- Runtime evidence lives under factory/state/cross_channel_media_smoke.json.

PASS requirements:
- Actual configured TTS provider generates WAV.
- Generated WAV duration is timeline authority.
- External SRT is built from actual line WAV durations.
- ffmpeg produces 1920x1080 MP4 and ffprobe verifies A/V duration tolerance.
- EN_STORY validates two Kokoro voices and fixed-frame Speaker Focus semantics.
- EN_BTS validates Kokoro information-first structured visual runs and subtitle-safe layout.
- JP_BTS resolves VOICEVOX speaker/style by names, not hard-coded style IDs, and validates deterministic two-role mapping.

Media readiness is evidence-driven. No channel may report ACTIVE_MEDIA_SMOKE unless its latest stored channel smoke status is PASS.
