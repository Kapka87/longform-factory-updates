# Longform Factory Cross-Channel Integration Spec v1.0

**Status:** FINAL LOCK
**Authority ID:** `LONGFORM_FACTORY_CROSS_CHANNEL_INTEGRATION_SPEC_v1_0`

Before Core v1 COMPLETE, EN_STORY, EN_BTS, JP_STORY and JP_BTS must operate as isolated channel profiles over one shared Core.

Phase 1:
- All four channels resolve through AdapterManager.
- Channel/profile mismatches fail.
- Core reads declared capabilities instead of embedding channel-specific production semantics.
- Existing Episode manifests are never auto-migrated.
- JP_STORY remains active media reference.
- EN_STORY / EN_BTS / JP_BTS are ACTIVE_CAPABILITY until representative media smoke passes.

Phase 2 media smoke order:
1. EN_STORY — Kokoro two-voice + Speaker Focus + actual-WAV subtitle timing.
2. EN_BTS — Kokoro information-first + BTS visual canonical + actual-WAV subtitle timing.
3. JP_BTS — VOICEVOX multi-voice role mapping + allowed gender pairings + actual-WAV subtitle timing.

No adapter may claim media readiness before its smoke test passes.
