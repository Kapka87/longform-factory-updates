from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, math, os, shutil, subprocess, traceback, urllib.parse, urllib.request, wave

CHANNELS=("EN_STORY","EN_BTS","JP_BTS")
STATE_REL=Path("factory/state/cross_channel_media_smoke.json")
QA_REL=Path("factory/_qa/cross_channel_media")

def _now(): return datetime.now(timezone.utc).isoformat()
def _slug_now(): return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
def _load(path):
 try: return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
 except Exception: return {}
def _save(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def _check(name,ok,detail=""): return {"name":name,"status":"PASS" if ok else "FAIL","detail":str(detail)}
def _run(cmd,timeout=180):
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
 if p.returncode!=0: raise RuntimeError("command failed: "+" ".join(map(str,cmd))+"\n"+p.stderr[-1600:])
 return p.stdout
def _wav_info(path):
 with wave.open(str(path),"rb") as w:
  frames=w.getnframes(); sr=w.getframerate(); ch=w.getnchannels(); sw=w.getsampwidth()
 return {"frames":frames,"sample_rate":sr,"channels":ch,"sample_width":sw,"duration":frames/sr if sr else 0}
def _write_pcm16(path,audio,sr):
 import numpy as np
 a=np.asarray(audio,dtype=np.float32).reshape(-1)
 a=np.clip(a,-1,1); pcm=(a*32767.0).astype("<i2")
 path.parent.mkdir(parents=True,exist_ok=True)
 with wave.open(str(path),"wb") as w:
  w.setnchannels(1); w.setsampwidth(2); w.setframerate(int(sr)); w.writeframes(pcm.tobytes())
def _concat_wavs(parts,out,gap_ms=220):
 infos=[_wav_info(p) for p in parts]
 if not infos: raise RuntimeError("no wav parts")
 sr=infos[0]["sample_rate"]; ch=infos[0]["channels"]; sw=infos[0]["sample_width"]
 if any((x["sample_rate"],x["channels"],x["sample_width"])!=(sr,ch,sw) for x in infos): raise RuntimeError("wav format mismatch")
 gap=b"\x00"*(int(sr*gap_ms/1000)*ch*sw)
 with wave.open(str(out),"wb") as dst:
  dst.setnchannels(ch); dst.setsampwidth(sw); dst.setframerate(sr)
  for i,p in enumerate(parts):
   with wave.open(str(p),"rb") as src: dst.writeframes(src.readframes(src.getnframes()))
   if i<len(parts)-1: dst.writeframes(gap)
 return _wav_info(out)
def _srt_time(sec):
 ms=max(0,int(round(sec*1000))); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000
 return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
def _write_srt(lines,durations,out,gap=0.22):
 t=0.0; blocks=[]
 for i,(txt,d) in enumerate(zip(lines,durations),1):
  blocks.append(f"{i}\n{_srt_time(t)} --> {_srt_time(t+d)}\n{txt}\n")
  t+=d+(gap if i<len(lines) else 0)
 out.write_text("\n".join(blocks),encoding="utf-8")
 return t
def _font(size):
 from PIL import ImageFont
 for p in ["/System/Library/Fonts/Supplemental/Arial.ttf","/System/Library/Fonts/Supplemental/Arial Bold.ttf","/Library/Fonts/Arial.ttf"]:
  if Path(p).exists():
   try:return ImageFont.truetype(p,size)
   except Exception: pass
 return ImageFont.load_default()
def _make_story_frames(outdir,count):
 from PIL import Image,ImageDraw
 out=[]
 for i in range(count):
  active=i%2
  im=Image.new("RGB",(1920,1080),(222,224,228)); d=ImageDraw.Draw(im)
  d.rectangle((0,0,959,820),fill=(205,208,214)); d.rectangle((960,0,1919,820),fill=(195,198,205))
  d.text((110,90),"EN_STORY MEDIA SMOKE",fill=(20,20,24),font=_font(52))
  d.text((250,360),"SPEAKER A",fill=(20,20,24),font=_font(70)); d.text((1210,360),"SPEAKER B",fill=(20,20,24),font=_font(70))
  overlay=Image.new("RGBA",im.size,(0,0,0,0)); od=ImageDraw.Draw(overlay)
  if active==0: od.rectangle((960,0,1919,820),fill=(0,0,0,153))
  else: od.rectangle((0,0,959,820),fill=(0,0,0,153))
  im=Image.alpha_composite(im.convert("RGBA"),overlay).convert("RGB"); d=ImageDraw.Draw(im)
  d.text((110,745),"Fixed frame · inactive side dimmed",fill=(30,30,34),font=_font(30))
  p=outdir/f"focus_{i+1:02d}.png"; im.save(p); out.append(p)
 return out
def _make_info_frames(outdir,label,count):
 from PIL import Image,ImageDraw
 out=[]
 for i in range(count):
  im=Image.new("RGB",(1920,1080),(244,245,247)); d=ImageDraw.Draw(im)
  d.text((120,95),label,fill=(20,22,28),font=_font(54))
  d.text((120,270),f"VISUAL RUN {i+1}",fill=(20,22,28),font=_font(92))
  d.text((120,455),"Actual generated audio controls this run.",fill=(45,48,55),font=_font(42))
  d.line((120,650,1700,650),fill=(100,105,115),width=3)
  d.text((120,700),"Subtitle-safe region begins below y=820",fill=(70,74,82),font=_font(30))
  # Keep y>=820 visually empty by design.
  p=outdir/f"run_{i+1:02d}.png"; im.save(p); out.append(p)
 return out
def _render(images,durations,audio,outdir):
 ffmpeg=shutil.which("ffmpeg"); ffprobe=shutil.which("ffprobe")
 if not ffmpeg or not ffprobe: raise RuntimeError("ffmpeg/ffprobe not found")
 concat=outdir/"visuals.ffconcat"
 rows=["ffconcat version 1.0"]
 for p,d in zip(images,durations):
  rows += [f"file '{str(p).replace(chr(39),chr(39)+chr(92)+chr(39)+chr(39))}'",f"duration {max(0.05,d):.6f}"]
 rows.append(f"file '{str(images[-1]).replace(chr(39),chr(39)+chr(92)+chr(39)+chr(39))}'")
 concat.write_text("\n".join(rows)+"\n",encoding="utf-8")
 silent=outdir/"silent.mp4"; final=outdir/"media_smoke.mp4"
 _run([ffmpeg,"-y","-hide_banner","-loglevel","error","-f","concat","-safe","0","-i",str(concat),"-vf","fps=30,format=yuv420p","-c:v","libx264","-preset","veryfast","-movflags","+faststart",str(silent)],240)
 _run([ffmpeg,"-y","-hide_banner","-loglevel","error","-i",str(silent),"-i",str(audio),"-c:v","copy","-c:a","aac","-b:a","160k","-shortest","-movflags","+faststart",str(final)],240)
 probe=json.loads(_run([ffprobe,"-v","error","-show_entries","format=duration:stream=width,height,codec_type","-of","json",str(final)],60))
 return final,probe
def _kokoro_lines(lines,voices,speeds,outdir):
 try:
  from kokoro import KPipeline
 except Exception as e: raise RuntimeError("Kokoro import failed: "+repr(e))
 import numpy as np
 pipe=KPipeline(lang_code="a"); parts=[]; durations=[]
 for i,(txt,voice,speed) in enumerate(zip(lines,voices,speeds),1):
  chunks=[]
  for item in pipe(txt,voice=voice,speed=float(speed)):
   audio=item[-1]
   chunks.append(np.asarray(audio,dtype=np.float32).reshape(-1))
  if not chunks: raise RuntimeError(f"Kokoro produced no audio for line {i}")
  p=outdir/f"line_{i:02d}_{voice}.wav"; _write_pcm16(p,np.concatenate(chunks),24000); parts.append(p); durations.append(_wav_info(p)["duration"])
 return parts,durations
def _http_json(url,method="GET",body=None,timeout=8):
 req=urllib.request.Request(url,data=body,method=method)
 if body is not None: req.add_header("Content-Type","application/json")
 with urllib.request.urlopen(req,timeout=timeout) as r: return json.loads(r.read().decode("utf-8"))
def _voicevox_alive(base):
 try:
  with urllib.request.urlopen(base+"/version",timeout=2) as r: return bool(r.read())
 except Exception: return False
def _try_voicevox_bootstrap(root,base):
 if _voicevox_alive(base): return "already_running"
 try:
  from adapters.voice import voicevox_bootstrap as vb
  for name in ("ensure_voicevox_engine","ensure_voicevox","ensure_engine","bootstrap_voicevox","start_voicevox"):
   fn=getattr(vb,name,None)
   if callable(fn):
    try:
     import inspect
     if len([p for p in inspect.signature(fn).parameters.values() if p.default is p.empty and p.kind in (p.POSITIONAL_ONLY,p.POSITIONAL_OR_KEYWORD)])==0:
      fn()
      import time
      for _ in range(30):
       if _voicevox_alive(base): return name
       time.sleep(0.3)
    except Exception:
     pass
 except Exception:
  pass
 return "not_started"
def _vv_style(speakers,speaker_names,style_names=("ノーマル","Normal")):
 for wanted in speaker_names:
  for sp in speakers:
   if sp.get("name")==wanted:
    styles=sp.get("styles",[])
    for sn in style_names:
     for st in styles:
      if st.get("name")==sn: return {"speaker":wanted,"style_name":st.get("name"),"style_id":st.get("id")}
    if styles: return {"speaker":wanted,"style_name":styles[0].get("name"),"style_id":styles[0].get("id")}
 return None
def _voicevox_lines(root,lines,outdir):
 base=os.environ.get("VOICEVOX_BASE_URL","http://127.0.0.1:50021").rstrip("/")
 boot=_try_voicevox_bootstrap(root,base)
 if not _voicevox_alive(base): raise RuntimeError("VOICEVOX engine unavailable at "+base+"; bootstrap="+boot)
 speakers=_http_json(base+"/speakers")
 a=_vv_style(speakers,["青山龍星"])
 b=_vv_style(speakers,["四国めたん","春日部つむぎ","冥鳴ひまり"])
 if not a or not b: raise RuntimeError("required VOICEVOX named speakers unavailable")
 selected=[a,b,a,b]; parts=[]; durations=[]
 for i,(txt,sel) in enumerate(zip(lines,selected),1):
  qurl=base+"/audio_query?"+urllib.parse.urlencode({"text":txt,"speaker":sel["style_id"]})
  q=_http_json(qurl,method="POST",body=b"{}")
  raw=json.dumps(q,ensure_ascii=False).encode("utf-8")
  surl=base+"/synthesis?"+urllib.parse.urlencode({"speaker":sel["style_id"]})
  req=urllib.request.Request(surl,data=raw,method="POST"); req.add_header("Content-Type","application/json")
  with urllib.request.urlopen(req,timeout=45) as r: wav=r.read()
  p=outdir/f"line_{i:02d}_{sel['speaker']}.wav"; p.write_bytes(wav); parts.append(p); durations.append(_wav_info(p)["duration"])
 return parts,durations,{"base_url":base,"bootstrap":boot,"role_map":{"A":a,"B":b}}
def _run_channel(root,cid):
 root=Path(root); outdir=root/QA_REL/cid/_slug_now(); outdir.mkdir(parents=True,exist_ok=False)
 checks=[]; evidence={}
 try:
  checks.append(_check("QA output isolation",str(outdir).startswith(str(root/"factory"/"_qa")) and cid in CHANNELS,str(outdir)))
  checks.append(_check("ffmpeg",bool(shutil.which("ffmpeg")),shutil.which("ffmpeg") or "missing"))
  checks.append(_check("ffprobe",bool(shutil.which("ffprobe")),shutil.which("ffprobe") or "missing"))
  try:
   import PIL
   checks.append(_check("Pillow",True,getattr(PIL,"__version__","available")))
  except Exception as e:
   checks.append(_check("Pillow",False,e))
  if not all(x["status"]=="PASS" for x in checks): raise RuntimeError("media prerequisites failed")

  gap=0.22
  if cid=="EN_STORY":
   lines=["I thought we agreed to meet here.","We did. I came because the evidence changed.","Then say what changed.","The timeline finally matches the recording."]
   voices=["af_heart","am_liam","af_heart","am_liam"]; speeds=[0.96,1.0,0.96,1.0]
   parts,durs=_kokoro_lines(lines,voices,speeds,outdir)
   images=_make_story_frames(outdir,len(lines))
   evidence["voice_roles"]={"A":"af_heart","B":"am_liam"}; evidence["speaker_focus"]="FIXED_FRAME_DIM_REST"
  elif cid=="EN_BTS":
   lines=["A queue number is not always the same thing as your final position.","The system can apply several gates before inventory is assigned.","That is why joining early does not guarantee the first offer."]
   voices=["af_heart"]*len(lines); speeds=[0.96]*len(lines)
   parts,durs=_kokoro_lines(lines,voices,speeds,outdir)
   images=_make_info_frames(outdir,"EN_BTS MEDIA SMOKE",len(lines))
   evidence["voice_roles"]={"narrator":"af_heart"}; evidence["visual_canonical"]="CONTAINERLESS_SUBTITLE_SAFE"
  elif cid=="JP_BTS":
   lines=["これはメディア統合の確認です。","役割ごとに音声を固定します。","実際の音声時間を基準にします。","字幕と映像も同じ時間軸で確認します。"]
   parts,durs,vm=_voicevox_lines(root,lines,outdir)
   images=_make_info_frames(outdir,"JP_BTS MEDIA SMOKE",len(lines))
   evidence["voice_roles"]=vm["role_map"]; evidence["style_resolution"]="DYNAMIC_BY_SPEAKER_AND_STYLE_NAME"; evidence["voicevox"]=vm
  else: raise RuntimeError("unsupported channel "+cid)

  master=outdir/"master.wav"; minfo=_concat_wavs(parts,master,int(gap*1000))
  srt=outdir/"upload.srt"; expected=_write_srt(lines,durs,srt,gap)
  visual_durs=[d+(gap if i<len(durs)-1 else 0) for i,d in enumerate(durs)]
  mp4,probe=_render(images,visual_durs,master,outdir)
  vdur=float(probe.get("format",{}).get("duration",0) or 0); adur=minfo["duration"]
  streams=probe.get("streams",[]); video=next((s for s in streams if s.get("codec_type")=="video"),{})
  checks += [
   _check("Generated WAV exists",master.exists() and master.stat().st_size>1000,master.stat().st_size if master.exists() else 0),
   _check("Actual-WAV timeline authority",abs(adur-expected)<0.08,f"wav={adur:.3f}s srt_timeline={expected:.3f}s"),
   _check("External SRT exists",srt.exists() and srt.stat().st_size>30,str(srt)),
   _check("1920x1080 render",video.get("width")==1920 and video.get("height")==1080,f"{video.get('width')}x{video.get('height')}"),
   _check("A/V duration sync",abs(vdur-adur)<0.20,f"video={vdur:.3f}s audio={adur:.3f}s"),
   _check("Rendered MP4 exists",mp4.exists() and mp4.stat().st_size>10000,mp4.stat().st_size if mp4.exists() else 0),
  ]
  status="PASS" if all(x["status"]=="PASS" for x in checks) else "FAIL"
  return {"channel_id":cid,"status":status,"started_and_finished_at":_now(),"checks":checks,"evidence":evidence,"outputs":{"root":str(outdir.relative_to(root)),"audio":str(master.relative_to(root)),"srt":str(srt.relative_to(root)),"video":str(mp4.relative_to(root))},"metrics":{"audio_duration":adur,"video_duration":vdur,"line_durations":durs}}
 except Exception as e:
  return {"channel_id":cid,"status":"FAIL","started_and_finished_at":_now(),"checks":checks+[_check("Smoke execution",False,str(e))],"evidence":evidence,"error":str(e),"traceback":"\n".join(traceback.format_exc().splitlines()[-12:]),"outputs":{"root":str(outdir.relative_to(root))}}

def media_smoke_status(root):
 p=Path(root)/STATE_REL
 d=_load(p)
 if not d: d={"schema":"LONGFORM_FACTORY_CROSS_CHANNEL_MEDIA_SMOKE_v1","updated_at":None,"state":"NOT_RUN","channels":{}}
 return d

def run_media_smoke(root,channel_id):
 root=Path(root); cid=(channel_id or "").strip().upper()
 if cid not in CHANNELS: raise ValueError("channel_id must be one of "+", ".join(CHANNELS))
 state=media_smoke_status(root); state.setdefault("channels",{})
 result=_run_channel(root,cid); state["channels"][cid]=result; state["updated_at"]=_now()
 vals=[state["channels"].get(x,{}).get("status") for x in CHANNELS]
 state["state"]="PASS" if all(x=="PASS" for x in vals) else ("FAIL" if any(x=="FAIL" for x in vals) else "PARTIAL")
 _save(root/STATE_REL,state)
 return state
