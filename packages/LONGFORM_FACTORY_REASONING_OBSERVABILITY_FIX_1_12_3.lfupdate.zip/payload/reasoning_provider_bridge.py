from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, re, uuid

TASK_ROOT=Path("factory/state/reasoning/tasks")
PROVIDER_ID="manual_handoff"

RESULT_SCHEMA={
 "type":"object",
 "required":["status","summary"],
 "properties":{
  "status":{"type":"string","enum":["PASS","REVIEW_REQUIRED","FAIL"]},
  "summary":{"type":"string"},
  "findings":{"type":"array","items":{"type":"object"}},
  "decisions":{"type":"array","items":{"type":"object"}},
  "next_action":{"type":["string","null"]},
 }
}

def _now(): return datetime.now(timezone.utc).isoformat()
def _write(path,obj): path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def _read(path):
 try:return json.loads(path.read_text(encoding="utf-8"))
 except Exception:return {}
def describe():
 return {"provider_id":PROVIDER_ID,"provider_type":"MANUAL_HANDOFF","contract":"LONGFORM_FACTORY_REASONING_PROVIDER_v1","description":"Provider-neutral manual bridge. Factory prepares a task packet; a human can run it in ChatGPT or another reasoning system and paste structured JSON back.","network_calls":False,"api_key_required":False}
def available(): return True
def supports_web(): return False
def result_schema(): return RESULT_SCHEMA
def _validate_result(x):
 if not isinstance(x,dict): raise ValueError("result must be a JSON object")
 if x.get("status") not in ("PASS","REVIEW_REQUIRED","FAIL"): raise ValueError("result.status invalid")
 if not isinstance(x.get("summary"),str) or not x.get("summary").strip(): raise ValueError("result.summary required")
 return True
def execute_task(root,task=None,result=None,task_id=None):
 root=Path(root)
 if result is None:
  if not isinstance(task,dict): raise ValueError("task object required")
  instruction=str(task.get("instruction") or "").strip()
  if not instruction: raise ValueError("task.instruction required")
  tid="RH_"+datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")+"_"+uuid.uuid4().hex[:6]
  packet={
   "schema":"LONGFORM_FACTORY_REASONING_TASK_v1","task_id":tid,"created_at":_now(),
   "provider_id":PROVIDER_ID,"status":"AWAITING_MANUAL_RESULT",
   "task_type":str(task.get("task_type") or "GENERAL"),
   "channel_id":task.get("channel_id"),"episode_id":task.get("episode_id"),
   "instruction":instruction,"context":task.get("context") or {},
   "result_schema":RESULT_SCHEMA,
   "manual_prompt":"Return JSON only matching result_schema. Task: "+instruction,
  }
  _write(root/TASK_ROOT/(tid+".json"),packet); return packet
 tid=str(task_id or "").strip()
 if not re.fullmatch(r"RH_[A-Za-z0-9_]+",tid): raise ValueError("valid task_id required")
 p=root/TASK_ROOT/(tid+".json")
 packet=_read(p)
 if not packet: raise FileNotFoundError("reasoning task not found")
 _validate_result(result)
 packet["status"]="COMPLETE"; packet["completed_at"]=_now(); packet["result"]=result
 _write(p,packet); return packet
def status(root):
 root=Path(root); d=root/TASK_ROOT
 rows=[]
 if d.exists():
  for p in sorted(d.glob("RH_*.json"),reverse=True)[:20]:
   x=_read(p); rows.append({"task_id":x.get("task_id"),"status":x.get("status"),"task_type":x.get("task_type"),"channel_id":x.get("channel_id"),"episode_id":x.get("episode_id"),"created_at":x.get("created_at")})
 return {"provider":describe(),"available":available(),"supports_web":supports_web(),"result_schema":result_schema(),"recent_tasks":rows}
