from __future__ import annotations
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone

_STATE={
    "installed": False,
    "request_count": 0,
    "last_url": None,
    "last_at": None,
}
_ORIG_URLOPEN=urllib.request.urlopen
_ORIG_OPENER_OPEN=urllib.request.OpenerDirector.open

def _now():
    return datetime.now(timezone.utc).isoformat()

def _is_feed_url(url):
    try:
        p=urllib.parse.urlsplit(str(url))
        return p.scheme in ("http","https") and p.path.rstrip("/").endswith("/feed.json")
    except Exception:
        return False

def _bust_url(url, nonce=None):
    p=urllib.parse.urlsplit(str(url))
    q=urllib.parse.parse_qsl(p.query,keep_blank_values=True)
    q=[(k,v) for (k,v) in q if k!="_lfcb"]
    q.append(("_lfcb",str(nonce if nonce is not None else time.time_ns())))
    return urllib.parse.urlunsplit((p.scheme,p.netloc,p.path,urllib.parse.urlencode(q),p.fragment))

def _request_with_no_cache(target):
    if isinstance(target,urllib.request.Request):
        url=target.full_url
        if not _is_feed_url(url):
            return target,None
        busted=_bust_url(url)
        headers=dict(target.header_items())
        headers["Cache-Control"]="no-cache"
        headers["Pragma"]="no-cache"
        req=urllib.request.Request(
            busted,
            data=target.data,
            headers=headers,
            method=target.get_method(),
        )
        return req,busted
    if isinstance(target,str) and _is_feed_url(target):
        busted=_bust_url(target)
        req=urllib.request.Request(
            busted,
            headers={"Cache-Control":"no-cache","Pragma":"no-cache"},
            method="GET",
        )
        return req,busted
    return target,None

def _mark(url):
    if not url:
        return
    _STATE["request_count"]+=1
    _STATE["last_url"]=url
    _STATE["last_at"]=_now()

def _patched_urlopen(url,*args,**kwargs):
    target,busted=_request_with_no_cache(url)
    _mark(busted)
    return _ORIG_URLOPEN(target,*args,**kwargs)

def _patched_opener_open(self,fullurl,*args,**kwargs):
    target,busted=_request_with_no_cache(fullurl)
    _mark(busted)
    return _ORIG_OPENER_OPEN(self,target,*args,**kwargs)

def install_update_feed_cache_bust():
    if _STATE["installed"]:
        return update_cache_bust_status()
    urllib.request.urlopen=_patched_urlopen
    urllib.request.OpenerDirector.open=_patched_opener_open
    _STATE["installed"]=True
    return update_cache_bust_status()

def update_cache_bust_status():
    return {
        "installed": bool(_STATE["installed"]),
        "strategy": "UNIQUE_QUERY_PLUS_NO_CACHE_HEADERS",
        "request_count": int(_STATE["request_count"]),
        "last_url": _STATE["last_url"],
        "last_at": _STATE["last_at"],
    }

def bust_url_for_test(url,nonce="TEST"):
    return _bust_url(url,nonce)
