from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, os, plistlib, shutil, subprocess, sys, tempfile

STATUS_REL=Path("factory/state/desktop_launcher_status.json")
MARKER_REL=Path("Contents/Resources/LongformFactoryLauncherVersion.txt")

def _now():
    return datetime.now(timezone.utc).isoformat()

def _write_status(root,data):
    p=Path(root)/STATUS_REL
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    tmp.replace(p)
    return data

def _marker(app):
    p=Path(app)/MARKER_REL
    try:
        return p.read_text(encoding="utf-8").strip()
    except Exception:
        return None

def _validate_app(app):
    app=Path(app)
    plist=app/"Contents/Info.plist"
    if not plist.exists():
        return False,"Info.plist missing"
    try:
        with plist.open("rb") as f:
            info=plistlib.load(f)
        exe=info.get("CFBundleExecutable")
        if not exe:
            return False,"CFBundleExecutable missing"
        ep=app/"Contents/MacOS"/exe
        if not ep.exists():
            return False,f"bundle executable missing: {exe}"
        return True,exe
    except Exception as e:
        return False,str(e)

def _applescript(shell_path):
    s=str(shell_path).replace("\\","\\\\").replace('"','\\"')
    return 'on run\n  do shell script "/bin/bash " & quoted form of "'+s+'" & " >/dev/null 2>&1 &"\nend run\n'

def ensure_desktop_launcher(root,app_path,launcher_version):
    root=Path(root).resolve()
    app=Path(app_path).expanduser().resolve()
    shell=root/"factory/launcher/launch_longform_factory.sh"
    base={
        "schema":"LONGFORM_FACTORY_DESKTOP_LAUNCHER_STATUS_v1",
        "checked_at":_now(),
        "launcher_version":str(launcher_version),
        "app_path":str(app),
        "shell_path":str(shell),
    }
    if sys.platform!="darwin":
        return _write_status(root,{**base,"state":"UNSUPPORTED_PLATFORM","repaired":False})
    if not shell.exists():
        return _write_status(root,{**base,"state":"ERROR","repaired":False,"error":"launcher shell missing"})
    try:
        shell.chmod(shell.stat().st_mode | 0o111)
    except Exception:
        pass
    ok,detail=_validate_app(app) if app.exists() else (False,"app missing")
    if ok and _marker(app)==str(launcher_version):
        return _write_status(root,{**base,"state":"READY","repaired":False,"bundle_executable":detail})

    osacompile=Path("/usr/bin/osacompile")
    if not osacompile.exists():
        return _write_status(root,{**base,"state":"ERROR","repaired":False,"error":"osacompile missing"})

    work=Path(tempfile.mkdtemp(prefix="lf_launcher_",dir=str(root/"factory/state")))
    src=work/"launcher.applescript"
    tmp_app=work/"Longform Factory.app"
    backup=None
    try:
        src.write_text(_applescript(shell),encoding="utf-8")
        proc=subprocess.run(
            [str(osacompile),"-o",str(tmp_app),str(src)],
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=30
        )
        if proc.returncode!=0:
            raise RuntimeError("osacompile failed: "+(proc.stderr or proc.stdout)[-1200:])
        marker=tmp_app/MARKER_REL
        marker.parent.mkdir(parents=True,exist_ok=True)
        marker.write_text(str(launcher_version)+"\n",encoding="utf-8")

        # Preserve the current icon when possible.
        old_icon=app/"Contents/Resources/applet.icns"
        new_icon=tmp_app/"Contents/Resources/applet.icns"
        if old_icon.exists() and new_icon.exists():
            try: shutil.copy2(old_icon,new_icon)
            except Exception: pass

        valid,exe=_validate_app(tmp_app)
        if not valid:
            raise RuntimeError("compiled app validation failed: "+str(exe))

        app.parent.mkdir(parents=True,exist_ok=True)
        if app.exists():
            stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            bdir=root/"factory/state/launcher_backups"
            bdir.mkdir(parents=True,exist_ok=True)
            backup=bdir/f"Longform_Factory_{stamp}.app"
            shutil.copytree(app,backup)
            shutil.rmtree(app)
        shutil.move(str(tmp_app),str(app))
        valid,exe=_validate_app(app)
        if not valid:
            raise RuntimeError("installed app validation failed: "+str(exe))
        return _write_status(root,{
            **base,
            "state":"READY",
            "repaired":True,
            "bundle_executable":exe,
            "backup":str(backup) if backup else None,
        })
    except Exception as e:
        if (not app.exists()) and backup and backup.exists():
            try: shutil.copytree(backup,app)
            except Exception: pass
        return _write_status(root,{**base,"state":"ERROR","repaired":False,"error":str(e),"backup":str(backup) if backup else None})
    finally:
        try: shutil.rmtree(work,ignore_errors=True)
        except Exception: pass

def launcher_status(root,app_path,launcher_version):
    root=Path(root).resolve(); app=Path(app_path).expanduser().resolve()
    p=root/STATUS_REL
    try:
        d=json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except Exception:
        d={}
    valid,detail=_validate_app(app) if app.exists() else (False,"app missing")
    return {
        **d,
        "state":"READY" if valid and _marker(app)==str(launcher_version) else d.get("state","NOT_READY"),
        "app_exists":app.exists(),
        "bundle_valid":bool(valid),
        "bundle_detail":detail,
        "marker":_marker(app),
        "expected_version":str(launcher_version),
    }
