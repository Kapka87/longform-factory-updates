#!/bin/bash
# Longform Factory Desktop Launcher v1.13.0
set -u

ROOT="${LONGFORM_FACTORY_ROOT:-$HOME/Desktop/KohoroAudition/LongformFactory_v1_Production}"
PY="${LONGFORM_FACTORY_PYTHON:-$HOME/Desktop/KohoroAudition/.venv/bin/python}"
URL="http://127.0.0.1:8765"
HEALTH="$URL/api/health"
STATE_DIR="$ROOT/factory/state"
LOG="$STATE_DIR/desktop_launcher.log"
LOCKDIR="/tmp/longform_factory_launcher_${UID}.lock"

health_ok() {
  /usr/bin/curl -fsS --max-time 1 "$HEALTH" 2>/dev/null | /usr/bin/grep -Eq '"ok"[[:space:]]*:[[:space:]]*true'
}

open_dashboard() {
  /usr/bin/open "$URL" >/dev/null 2>&1
}

alert() {
  /usr/bin/osascript -e "display alert \"Longform Factory\" message \"$1\"" >/dev/null 2>&1 || true
}

if health_ok; then
  open_dashboard
  exit 0
fi

if ! /bin/mkdir "$LOCKDIR" 2>/dev/null; then
  i=0
  while [ "$i" -lt 25 ]; do
    if health_ok; then open_dashboard; exit 0; fi
    /bin/sleep 0.2
    i=$((i+1))
  done
fi
trap '/bin/rmdir "$LOCKDIR" >/dev/null 2>&1 || true' EXIT

if /usr/sbin/lsof -nP -iTCP:8765 -sTCP:LISTEN >/dev/null 2>&1; then
  i=0
  while [ "$i" -lt 20 ]; do
    if health_ok; then open_dashboard; exit 0; fi
    /bin/sleep 0.2
    i=$((i+1))
  done
  alert "Port 8765 is already in use by another process. Open the Factory from Terminal and inspect the listener before retrying."
  exit 2
fi

if [ ! -d "$ROOT" ]; then
  alert "Factory root was not found at $ROOT"
  exit 3
fi
if [ ! -x "$PY" ]; then
  alert "Factory Python environment was not found at $PY"
  exit 4
fi

/bin/mkdir -p "$STATE_DIR"
cd "$ROOT" || exit 5
/usr/bin/nohup "$PY" "$ROOT/factory/control_center_current.py" >>"$LOG" 2>&1 &

i=0
while [ "$i" -lt 80 ]; do
  if health_ok; then
    open_dashboard
    exit 0
  fi
  /bin/sleep 0.25
  i=$((i+1))
done

alert "Control Center did not become healthy. Check factory/state/desktop_launcher.log."
exit 6
