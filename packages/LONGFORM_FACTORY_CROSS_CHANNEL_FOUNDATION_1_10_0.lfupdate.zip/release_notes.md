# Longform Factory v1.10.0 — Cross-Channel Integration Foundation

EN_STORY, EN_BTS and JP_BTS move from PENDING to ACTIVE_CAPABILITY. JP_STORY remains active media reference. Adds Dashboard → Channels QA. No existing Episode manifest is migrated.
