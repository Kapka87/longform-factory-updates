from __future__ import annotations
from pathlib import Path

STAGES=["DISCOVERY","GREENLIGHT","RESEARCH","FACT_LOCK","SCRIPT","SCRIPT_QC","VISUAL_PLAN","VISUAL_BUILD","VISUAL_QC","VOICE","TIMING","SUBTITLES","EDIT_PLAN","RENDER","AUTO_QC","PREVIEW_REVIEW","FINAL","THUMBNAIL","TITLE","DESCRIPTION","TAGS","PUBLISHING_QC","PUBLISHING_REVIEW","UPLOAD_READY"]

class DeclarativeCapabilityAdapter:
    ADAPTER_ID=""
    CHANNEL_ID=""
    PROFILE_ID=""
    DISPLAY_NAME=""
    REQUIRED_RULES=[]
    CAPABILITIES={}
    def __init__(self,root:Path): self.root=Path(root)
    def describe(self,context):
        return {"adapter_contract":"1.0","adapter_id":self.ADAPTER_ID,"adapter_version":"1.0","channel_id":self.CHANNEL_ID,"profile_id":self.PROFILE_ID,"display_name":self.DISPLAY_NAME,"integration_status":"ACTIVE_CAPABILITY","media_binding":"PENDING_MEDIA_SMOKE","supported_stages":list(STAGES),"required_rules":list(self.REQUIRED_RULES),"capabilities":self.CAPABILITIES,"requires":{"core_contract":">=1.0,<2.0","manifest_schema":">=1.2,<2.0","profile":self.PROFILE_ID}}
    def inspect(self,ep,manifest):
        return {"active":True,"adapter_id":self.ADAPTER_ID,"stage":manifest.get("lifecycle",{}).get("current_stage","DISCOVERY"),"state":"CAPABILITY_INTEGRATED","buttons":[],"integration_status":"ACTIVE_CAPABILITY","media_binding":"PENDING_MEDIA_SMOKE","message":"Channel capability contract is integrated. Media runner smoke test is still required."}
    def preflight(self,stage,context):
        m=context["manifest"]
        checks=[
          {"name":"Manifest schema","pass":str(m.get("schema_version"))=="1.2","detail":str(m.get("schema_version"))},
          {"name":"Channel","pass":m.get("channel_id")==self.CHANNEL_ID,"detail":str(m.get("channel_id"))},
          {"name":"Profile","pass":m.get("profile")==self.PROFILE_ID,"detail":str(m.get("profile"))},
        ]
        return {"pass":all(x["pass"] for x in checks),"checks":checks,"resource_class":"LIGHT"}
    def job_spec(self,job_name,context): return None
    def artifacts(self,stage,context): return []
    def retry_policy(self,stage,failure,context): return {"retryable":False,"resume_point":None,"cache_reuse":False,"max_safe_retries":0,"human_intervention":True}
    def invoke_action(self,action,context,body):
        raise RuntimeError(f"{self.CHANNEL_ID} capability adapter is integrated, but action '{action}' requires the channel media/reasoning smoke phase.")
