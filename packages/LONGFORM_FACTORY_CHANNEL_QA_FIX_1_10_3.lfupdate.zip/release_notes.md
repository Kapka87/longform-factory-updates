# Longform Factory v1.10.3 — Cross-Channel QA Wiring + Logic Fix

Preserves the v1.10.2 runtime health fix. Channels QA now shows RUNNING/success/error, consumes the POST body correctly, and profile-isolation checks use the actual adapter compatibility path. Reinstalls four-channel adapter registry/package boundaries. No project, episode manifest, or LOCK asset is modified.
