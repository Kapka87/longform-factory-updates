#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import os, runpy
ROOT=Path(os.environ.get("LONGFORM_FACTORY_ROOT",str(Path.home()/"Desktop"/"KohoroAudition"/"LongformFactory_v1_Production"))).expanduser().resolve()
src=ROOT/"factory/control_center_current.py"
text=src.read_text(encoding="utf-8")
text=repl=text.replace('FACTORY_VERSION="1.13.0"','FACTORY_VERSION="1.14.0"',1)
text=text.replace('if channel=="JP_STORY" and str(m.get("schema_version"))=="1.2":','if str(m.get("schema_version"))=="1.2":',1)
imp='from four_channel_production_integration import four_channel_production_status, run_four_channel_production_qa\n'
anchor='from cross_channel_media_smoke import media_smoke_status, run_media_smoke\n'
if imp.strip() not in text:
    if anchor not in text: raise RuntimeError("v1.14 bootstrap import anchor missing")
    text=text.replace(anchor,anchor+imp,1)
get_anchor='        if u.path=="/qa":\n'
get_block='        if u.path=="/api/four-channel-production/status":\n            self.send_json(four_channel_production_status(ROOT)); return\n'
if '/api/four-channel-production/status' not in text:
    if get_anchor not in text: raise RuntimeError("v1.14 GET anchor missing")
    text=text.replace(get_anchor,get_block+get_anchor,1)
post_anchor='            if self.path=="/api/updates/upload":\n'
post_block='            if self.path=="/api/four-channel-production/run":\n                try:\n                    _body=self.read_body()\n                    self.send_json(run_four_channel_production_qa(ROOT),200); return\n                except Exception as e: self.send_json({"ok":False,"error":"4-Channel Production QA failed: "+str(e)},400); return\n'
if '/api/four-channel-production/run' not in text:
    if post_anchor not in text: raise RuntimeError("v1.14 POST anchor missing")
    text=text.replace(post_anchor,post_block+post_anchor,1)
# Visible version label follows runtime authority.
text=text.replace('<div class="ver">v1.13.0</div>','<div class="ver">v1.14.0</div>')
runtime=ROOT/"factory/state/control_center_v114_runtime.py"; runtime.parent.mkdir(parents=True,exist_ok=True); runtime.write_text(text,encoding="utf-8")
runpy.run_path(str(runtime),run_name="__main__")
