# Longform Factory v1.14.0 — Four-Channel Production Integration

- EN_STORY production adapter + Kokoro two-voice story runner + fixed-frame Speaker Focus
- EN_BTS production v1.2 with publishing approval through UPLOAD_READY
- JP_BTS production adapter + dynamic VOICEVOX speaker/style mapping
- JP_STORY remains the active media reference
- Adapter Registry v2.0
- Four-channel isolated production QA
- Existing Episode adapter pins are never auto-migrated
- Image generation remains provider-neutral
