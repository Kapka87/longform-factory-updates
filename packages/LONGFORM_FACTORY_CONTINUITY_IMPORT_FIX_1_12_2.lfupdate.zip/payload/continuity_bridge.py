from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, re

CHANNELS={
 "EN_STORY":{"profile":"EN_DRAMA_v1","adapter":"EN_STORY_REFERENCE_ADAPTER_v1_0","rules":["STORY_LONGFORM_EDITING_CANONICAL_RULES_v1_0"]},
 "EN_BTS":{"profile":"EN_TECH_v1","adapter":"EN_BTS_REFERENCE_ADAPTER_v1_0","rules":["BTS_CANONICAL_VISUAL_TEMPLATE_v1_1"]},
 "JP_STORY":{"profile":"JP_STORY_v1","adapter":"JP_STORY_REFERENCE_ADAPTER_v1_4","rules":["JP_STORY_SUPERVISED_FACTORY"]},
 "JP_BTS":{"profile":"JP_TECH_v1","adapter":"JP_BTS_REFERENCE_ADAPTER_v1_0","rules":["LONGFORM_FACTORY_JP_VOICE_CASTING_POLICY_v1_0"]},
}
REGISTRY_REL=Path("factory/handoff/registry.json")
EP_RE=re.compile(r"_(?:EP)(\d{3})$")

def _now(): return datetime.now(timezone.utc).isoformat()
def _read(path,default=None):
 try:return json.loads(path.read_text(encoding="utf-8")) if path.exists() else ({} if default is None else default)
 except Exception:return {} if default is None else default
def _write_json(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def _write_text(path,text):
 path.parent.mkdir(parents=True,exist_ok=True); path.write_text(text.rstrip()+"\n",encoding="utf-8")
def _episode_num(name):
 m=EP_RE.search(name); return int(m.group(1)) if m else -1
def _manifest_candidates(root,cid):
 ep_root=Path(root)/"projects"/cid/"episodes"
 if not ep_root.exists(): return []
 rows=[]
 for d in ep_root.iterdir():
  if not d.is_dir(): continue
  p=d/"episode_manifest.json"
  if p.exists(): rows.append((d,p,_read(p,{})))
 return sorted(rows,key=lambda x:(_episode_num(x[0].name),x[0].name))
def _locked_assets(m):
 out=[]
 auth=m.get("authority",{}) if isinstance(m.get("authority",{}),dict) else {}
 for k,v in auth.items():
  if isinstance(v,str) and v: out.append({"role":k,"value":v})
 return out[:40]
def _stage(m): return (m.get("lifecycle") or {}).get("current_stage") or "UNKNOWN"
def _episode_status(m): return (m.get("lifecycle") or {}).get("status") or m.get("status") or "UNKNOWN"
def _safe_episode_handoff(m):
 try:return float(str(m.get("schema_version","0")))>=1.2
 except Exception:return False

def _episode_state(root,cid,d,m):
 eid=m.get("episode_id") or d.name
 stage=_stage(m); status=_episode_status(m)
 return {
  "schema":"LONGFORM_FACTORY_EPISODE_STATE_v1",
  "generated_at":_now(),
  "channel_id":cid,
  "episode_id":eid,
  "AUTHORITY":{"manifest":str((d/"episode_manifest.json").relative_to(root)),"schema_version":str(m.get("schema_version",""))},
  "CURRENT_STAGE":stage,
  "LOCKED_ASSETS":_locked_assets(m),
  "ACTIVE_RULES":CHANNELS[cid]["rules"],
  "OPEN_DECISIONS":[],
  "KNOWN_FAILURES":[],
  "NEXT_ACTION":"Continue from Factory manifest current stage: "+stage,
  "DO_NOT_REOPEN":["LOCK/FINAL_LOCK assets unless a concrete production failure requires it","completed earlier stages without an explicit authority change"],
  "status":status,
 }
def _episode_md(s):
 return f"""# {s['episode_id']} — Chat Handoff
AUTHORITY: {s['AUTHORITY']['manifest']}
CURRENT_STAGE: {s['CURRENT_STAGE']}
STATUS: {s['status']}
ACTIVE_RULES: {', '.join(s['ACTIVE_RULES']) or 'none'}
NEXT_ACTION: {s['NEXT_ACTION']}

DO_NOT_REOPEN:
"""+"\n".join("- "+x for x in s["DO_NOT_REOPEN"])

def generate_continuity_snapshot(root):
 root=Path(root)
 media=_read(root/"factory"/"state"/"cross_channel_media_smoke.json",{})
 qa=_read(root/"factory"/"state"/"cross_channel_qa.json",{})
 old=_read(root/REGISTRY_REL,{})
 result={"schema":"LONGFORM_FACTORY_HANDOFF_REGISTRY_v1","generated_at":_now(),"factory_version":"1.12.2","channels":{}}
 for cid,cfg in CHANNELS.items():
  eps=_manifest_candidates(root,cid)
  latest=eps[-1] if eps else None
  old_ch=(old.get("channels",{}).get(cid,{}) or {})
  active_hint=old_ch.get("active_workstream_hint")
  next_hint=old_ch.get("next_action_hint")
  inferred_episode=(latest[2].get("episode_id") or latest[0].name) if latest else None
  active_episode=active_hint or inferred_episode
  active_stage=("PINNED_EXTERNAL_WORKSTREAM" if active_hint and active_hint!=inferred_episode else (_stage(latest[2]) if latest else "NO_FACTORY_MANAGED_EPISODE"))
  ch_media=(media.get("channels",{}).get(cid,{}) or {}).get("status")
  state={
   "schema":"LONGFORM_FACTORY_CHANNEL_STATE_v1","generated_at":_now(),"channel_id":cid,
   "AUTHORITY":{"profile":cfg["profile"],"adapter":cfg["adapter"],"registry":str(REGISTRY_REL)},
   "CURRENT_STAGE":active_stage,
   "LOCKED_ASSETS":[],
   "ACTIVE_RULES":cfg["rules"],
   "OPEN_DECISIONS":[],
   "KNOWN_FAILURES":[],
   "NEXT_ACTION":next_hint or ("Resume "+active_episode+" from "+active_stage if active_episode else "Declare or create the next Factory-managed workstream."),
   "DO_NOT_REOPEN":["legacy completed episodes","LOCK/FINAL_LOCK assets without concrete failure evidence","superseded production paths"],
   "active_episode":active_episode,
   "active_workstream_hint":active_hint,
   "media_smoke":ch_media or ("ACTIVE_REFERENCE" if cid=="JP_STORY" else "NOT_RUN"),
   "cross_channel_qa":qa.get("state","NOT_RUN"),
  }
  hp=root/"projects"/cid/"handoff"; _write_json(hp/"CHANNEL_STATE.json",state)
  md=f"""# {cid} — Channel Handoff
AUTHORITY: {cfg['profile']} / {cfg['adapter']}
CURRENT_STAGE: {active_stage}
ACTIVE_EPISODE: {active_episode or 'none detected'}
ACTIVE_WORKSTREAM_HINT: {active_hint or 'none'}
MEDIA: {state['media_smoke']}
NEXT_ACTION: {state['NEXT_ACTION']}

ACTIVE_RULES:
"""+"\n".join("- "+x for x in cfg["rules"])+"""\n
DO_NOT_REOPEN:
"""+"\n".join("- "+x for x in state["DO_NOT_REOPEN"])
  _write_text(hp/"CHANNEL_HANDOFF.md",md)
  episode_pointer=None
  if latest and _safe_episode_handoff(latest[2]):
   es=_episode_state(root,cid,latest[0],latest[2]); eh=latest[0]/"handoff"
   _write_json(eh/"EPISODE_STATE.json",es); _write_text(eh/"CHAT_HANDOFF.md",_episode_md(es))
   episode_pointer=str((eh/"EPISODE_STATE.json").relative_to(root))
  result["channels"][cid]={
   "channel_state":str((hp/"CHANNEL_STATE.json").relative_to(root)),
   "channel_handoff":str((hp/"CHANNEL_HANDOFF.md").relative_to(root)),
   "active_episode":active_episode,
   "active_episode_state":episode_pointer,
   "active_workstream_hint":active_hint,
   "current_stage":active_stage,
  }
 _write_json(root/REGISTRY_REL,result)
 return result

def continuity_status(root):
 root=Path(root); p=root/REGISTRY_REL
 if not p.exists(): return {"state":"NOT_GENERATED","registry":str(REGISTRY_REL),"channels":{}}
 d=_read(p,{})
 return {"state":"READY","registry":str(REGISTRY_REL),"generated_at":d.get("generated_at"),"channels":d.get("channels",{})}

def set_active_workstream_hint(root,channel_id,episode_id,next_action=None):
 root=Path(root); cid=(channel_id or "").upper().strip()
 if cid not in CHANNELS: raise ValueError("unknown channel")
 if episode_id and not re.fullmatch(r"[A-Z_]+_EP\d{3}",episode_id): raise ValueError("episode_id must use CHANNEL_EP###")
 reg=_read(root/REGISTRY_REL,{})
 reg.setdefault("schema","LONGFORM_FACTORY_HANDOFF_REGISTRY_v1"); reg.setdefault("channels",{})
 reg["channels"].setdefault(cid,{})["active_workstream_hint"]=episode_id or None
 if next_action: reg["channels"][cid]["next_action_hint"]=str(next_action)
 reg["generated_at"]=_now(); _write_json(root/REGISTRY_REL,reg)
 return generate_continuity_snapshot(root)
