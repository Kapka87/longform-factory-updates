# Longform Factory v1.10.2 — Runtime Health Fix + Cross-Channel Recovery

Fixes the stale /api/health version that caused valid installs to be rolled back to 1.9.9. Runtime version reporting now uses one FACTORY_VERSION authority and the health endpoint reports the actual updater API constant. Reinstalls four-channel adapter registry/package boundaries. No project, episode manifest, or LOCK asset is modified.
