# Longform Factory v1.10.1 — Runtime Repair + Cross-Channel Recovery

Repairs mixed/rolled-back runtime state. Reinstalls the four-channel adapter registry and explicit package boundaries. No project, episode manifest, or LOCK asset is modified.
